		<table align="center"><tr><td>	
<table style="margin-top:-3px;width:251px;border-collapse: collapse;">
<tr style="background:#7BC91D;height:50px;"><td style="border-radius: 4px 4px 0px 0px;color:#fff;padding:10px;font-size:32px;text-align:center;font-family:cuprum;">
<b><?=$UserInfo['MoneyIn'];?> <span style="font-size:25px;">руб.</span></b>
</td></tr>
<tr style="background:#5BB410;height:32px;"><td style="text-align:center;font-size:18px;">БАЛАНС ДЛЯ ПОКУПОК</td><tr>
</table>
<center><a href="/insert" class="btnAccleft">Пополнить</a></center><br>
<table  align="center" style="width:251px;border-collapse: collapse;">
<tr style="background:#7BC91D;height:50px;"><td style="color:#fff;padding:10px;font-size:32px;text-align:center;font-family:cuprum;">
<b><?=$UserInfo['MoneyOut'];?> <span style="font-size:25px;">руб.</span></b>
</td></tr>
<tr style="background:#5BB410;height:32px;"><td style="text-align:center;font-size:18px;">БАЛАНС ДЛЯ ВЫВОДА</td><tr>
</table>
<center><a href="/payment" class="btnAcc" style="border-radius: 0px 0px 4px 4px ;">Вывести</a></center>
<br>
</td></tr></table>
<table align="center"><tr><td>	


<table  align="center" style="width:251px;border-collapse: collapse;">
<tr style="background:#7BC91D;height:32px;"><td style="font-family: 'Cuprum';border-radius: 4px 4px 0px 0px;text-align:center;font-size:20px;color:#fff;"><b>МЕНЮ АККАУНТА</b></td><tr>
</table>
<center><a href="/user/" class="btnAcc1" style="">Мой профиль</a></center>
<center><a href="/garden" class="btnAcc1" style="">Мой сад</a></center>
<center><a href="/shop" class="btnAcc1" style="">Магазин саженцев</a></center>
<center><a href="/referals" class="btnAcc1" style="border-radius: 0px 0px 4px 4px ;">Мои рефералы</a></center>
<br>
</td></tr></table>

<table align="center"><tr><td>	
<table  align="center" style="width:251px;border-collapse: collapse;">
<tr style="background:#7BC91D;height:32px;"><td style="font-family: 'Cuprum';border-radius: 4px 4px 0px 0px;text-align:center;font-size:20px;color:#fff;"><b>КОНКУРСЫ И АКЦИИ</b></td><tr>
</table>
<center><a href="/creferals" class="btnAcc1" style="color:#bc281e;">Конкурс рефералов</a></center>
<center><a href="/cinvestors" class="btnAcc1" style="color:#bc281e;border-radius: 0px 0px 4px 4px ;">Конкурс инвесторов</a></center>
<br>
</td></tr></table>

<table align="center"><tr><td>	
<table  align="center" style="width:251px;border-collapse: collapse;">
<tr style="background:#7BC91D;height:32px;"><td style="font-family: 'Cuprum';border-radius: 4px 4px 0px 0px;text-align:center;font-size:20px;color:#fff;"><b>РАЗНОЕ</b></td><tr>
</table>
<center><a href="/bonus" class="btnAcc1" style="color:green;">Ежедневный бонус</a></center>
<center><a href="/stats" class="btnAcc1" style="color:#2d22d2;">Статистика проекта</a></center>
<center><a href="/chat" class="btnAcc1" style="">Онлайн ЧАТ</a></center>
<center><a href="/info" class="btnAcc1" style="color:#bc281e;border-radius: 0px 0px 4px 4px ;">Игровое обучение</a></center>
<br>
</td></tr></table>		

<table align="center"><tr><td>	
<table  align="center" style="width:251px;border-collapse: collapse;">
<tr style="background:#7BC91D;height:32px;"><td style="font-family: 'Cuprum';border-radius: 4px 4px 0px 0px;text-align:center;font-size:20px;color:#fff;"><b>Развлечения</b></td><tr>
</table>
<center><a href="/knb" class="btnAcc1" style="border-radius: 0px 0px 4px 4px;">КНБ</a></center>
<br>
</td></tr></table>	