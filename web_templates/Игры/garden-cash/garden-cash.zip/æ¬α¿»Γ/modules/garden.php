<?

if(!isset($_SESSION['id'])){
		Header("Location: /");
		exit;
}

?>

<?
if(isset($_GET['sbor'])){
	$q = $mysql->query("SELECT * FROM db_farm WHERE UserId = '".$_SESSION['id']."'");
	$i = 0;
	while($row = $q->fetch()){
		
		if($row['Type'] == 1) {
			$cop = (($dohod['full_1'] / 24) / 3600) * (time() - $row['Lastdate']);
		}elseif($row['Type'] == 2){
			$cop = (($dohod['full_2'] / 24) / 3600) * (time() - $row['Lastdate']);
		}elseif($row['Type'] == 3){
			$cop = (($dohod['full_3'] / 24) / 3600) * (time() - $row['Lastdate']);
		}elseif($row['Type'] == 4){
			$cop = (($dohod['full_4'] / 24) / 3600) * (time() - $row['Lastdate']);
		}elseif($row['Type'] == 5){
			$cop = (($dohod['full_5'] / 24) / 3600) * (time() - $row['Lastdate']);
		}elseif($row['Type'] == 6){
			$cop = (($dohod['full_6'] / 24) / 3600) * (time() - $row['Lastdate']);
		}
		
		if($cop >= 0.01){
			$mysql->query("UPDATE db_farm SET `Lastdate` = '".time()."' WHERE Id = '".$row['Id']."' AND UserId = '".$_SESSION['id']."'");
			$mysql->query("UPDATE db_users SET MoneyOut = MoneyOut + '$cop' WHERE Id = '".$_SESSION['id']."'");
			$i++;
		}
		
		$copp = sprintf('%01.2f', $copp + $cop);
	}
	$mysql->query("INSERT INTO db_logs SET UserId = '".$_SESSION['id']."', Text = 'Начисление дохода $copp руб.', Date = '".time()."'");
	if($i > 1){
		$_SESSION['sbor'] = TextOk('Успешно собрали ');
	}else {
		$_SESSION['sbor'] = TextNo('Нечего собирать');
	}
	Header("Location: /garden");
	exit;
}


	echo $_SESSION['sbor'];
	unset ($_SESSION['sbor']);




?>

<div class="holder box grass">
		<div class="info">
		<div style="padding: 10px 10px 10px 50px;">
		Вы находитесь в разделе "Мой сад", правда здесь красиво? Тут Вы можете наблюдать за накоплением рублей с купленных вами деревьев, снять  можно минимум 1 копейку.
		</div>
		</div><br>
			<table class="statsTable" style="margin-top:-10px;"><tr><th colspan="2">Ваши деревья:</th></tr></table>		
            <table  align="center">
            <tr><td align="center">
 <?
$q = $mysql->query("SELECT * FROM db_farm WHERE `UserId` = '".$_SESSION['id']."'");
if($q->rowCount() >= 1){
while($p = $q->fetch()){
	switch($p['Type']){
		case 1: $cl = 'one'; $name = 'Вишня'; break;
		case 2: $cl = 'two'; $name = 'Слива'; break;
		case 3: $cl = 'three'; $name = 'Яблоня'; break;
		case 4: $cl = 'four'; $name = 'Персик'; break;
		case 5: $cl = 'five'; $name = 'Груша'; break;
		case 6: $cl = 'six'; $name = 'Апельсин'; break;
	}
	
	if($p['Type'] == 1) {
		$cop = (($dohod['full_1'] / 24) / 3600) * (time() - $p['Lastdate']);
	}elseif($p['Type'] == 2){
		$cop = (($dohod['full_2'] / 24) / 3600) * (time() - $p['Lastdate']);
	}elseif($p['Type'] == 3){
		$cop = (($dohod['full_3'] / 24) / 3600) * (time() - $p['Lastdate']);
	}elseif($p['Type'] == 4){
		$cop = (($dohod['full_4'] / 24) / 3600) * (time() - $p['Lastdate']);
	}elseif($p['Type'] == 5){
		$cop = (($dohod['full_5'] / 24) / 3600) * (time() - $p['Lastdate']);
	}elseif($p['Type'] == 6){
		$cop = (($dohod['full_6'] / 24) / 3600) * (time() - $p['Lastdate']);
	}
?>			
            <!-- start PLAN -->
			<div class="plan">
			
				<p class="image <?=$cl;?>"></p>
				<p class="percentage"><?=$name;?></p>
				<p class="period">Накоплено:</p>
				<p class="limit"><?=sprintf("%.3f", $cop);?> руб.</p>
			
			</div>
			<!-- end PLAN -->
<? } 

}else echo '<center><h3>У Вас нет саженцев</h3></center>';
?>           			

			
			
            						</td></tr></table>
			<center><a href="/shop" style="border-bottom:1px dashed;font-size:16px;">Докупить саженцы фруктовых растений</a></center>	
			<BR> <div class="sadtext" style="text-align: center;">--------------------</div>
			<BR><center><a href="/garden?sbor" class="button green medium">Собрать накопления</a><br>минимум для сбора 0,01 руб.</center>
			<link rel="stylesheet" type="text/css" href="../buttons/buttons.css" />