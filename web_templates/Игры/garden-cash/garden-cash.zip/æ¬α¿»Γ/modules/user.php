<?

if(!isset($_SESSION['id'])){
		Header("Location: /");
		exit;
}

?>
<div class="top">
<p class="user"><span><?=$_SESSION['login'];?></span><br />Дата создания аккаунта: <?=date("d.m.Yг.", $UserInfo['DateReg']);?></p>
				
				<!-- start LINK -->
				<div class="link">
				
					<p class="title">Ваша реферальная ссылка:</p>
					<p class="url">http://<?=$_SERVER['HTTP_HOST'];?>/?ref=<?=$_SESSION['login'];?></p>
				
				</div>
				<!-- end LINK -->
				
				<div class="clr"></div>
			
			</div>
			<!-- end TOP -->
				
			<!-- start HOLDER -->
			<div class="holder box grass">
				<center><a href="/setting" style="border-bottom:1px dashed;font-size:16px;">НАСТРОЙКИ</a> <a href="#">//&nbsp;</a><a href="/logs" style="border-bottom:1px dashed;font-size:16px;">ИСТОРИЯ АККАУНТА</a></center>
				<table class="statsTable">
					<tr>
						<th colspan="2">Статистика аккаунта:</th>
					</tr>
                    <tr>
						<td>Всего пополнено:</td>
						<td class="value"><?=$UserInfo['MoneyP']; ?> руб.</td>
					</tr>
					<tr>
						<td>Всего выведено:</td>
						<td class="value"><?=$UserInfo['MoneyB']; ?> руб.</td>
					</tr>
				
				</table>

				<table class="statsTable">
					<tr>
						<th colspan="2">Информация об аккаунте:</th>
					</tr>
					<tr>
						<td>Логин/псевдоним:</td>
						<td class="value"><?=$_SESSION['login'];?></td>
					</tr>
					<tr>
						<td>ID вашего аккаунта в системе:</td>
						<td class="value"><?=$_SESSION['id'];?></td>
					</tr>
					<tr>
						<td>E-mail аккаунта:</td>
						<td class="value"><?=$UserInfo['Email'];?></td>
					</tr>
					<tr>
						<td>Вас пригласил:</td>
						<?
						$d = $mysql->query("SELECT Login FROM db_users WHERE Id = '".$UserInfo['RefId']."'");
						$RefName = $d->fetch();
						?>
						<td class="value"><?=$RefName['Login']; ?></td>
					</tr>
				</table>
				
				<table class="statsTable">
					<tr>
						<th colspan="2">Статистика партнерской программы:</th>
					</tr>
										<tr>
						<td>Всего рефералов:</td>
						<td class="value"><?=$UserInfo['CountRef']; ?> чел.</td>
					</tr>
										<tr>
						<td>Заработано на рефералах:</td>
						<td class="value"><?=$UserInfo['RefMoney'];?> руб.</td>
					</tr>
					
				</table>
<center><a href="/referals" style="border-bottom:1px dashed;font-size:16px;">Подробнее о партнерской программе</a></center>
</table>
