<?

if(!isset($_SESSION['id'])){
		Header("Location: /");
		exit;
}

?>
<!-- start HOLDER -->

			<div class="holder box grass">
		<div class="info">
		<div style="padding: 10px 10px 10px 50px;">
	    В нашем проекте любой его игрок может принять участие в партнерской программе. Приглашайте своих друзей и знакомых, и получайте <b>10% от всех их пополнений сразу на свой счет для вывода.</b>
		</div>
		</div>
		<BR><div class="link" style="float:left;">
				
					<p class="title">Ваша реферальная ссылка:</p>
					<p class="url">http://<?=$_SERVER['HTTP_HOST'];?>/?ref=<?=$_SESSION['login'];?></p>
				
		</div>
		<BR><BR><BR><BR><center><a href="/promo" style="border-bottom:1px dashed;font-size:20px;color:#d22;"><b>РЕКЛАМНЫЕ МАТЕРИАЛЫ И БАННЕРЫ</b></a></center><BR>
				<table class="statsTable">
					<tr>
						<th colspan="2">Статистика партнерской программы:</th>
					</tr>
					<tr>
						<td>Всего рефералов:</td>
						<td class="value"><?=$UserInfo['CountRef'];?> чел.</td>
					</tr>
					<?
					$r = $mysql->query("SELECT * FROM db_users WHERE RefId = '".$_SESSION['id']."' AND MoneyP > '0'");
					?>
					<tr>
						<td>Активных рефералов:</td>
						<td class="value"><?=$r->rowCount();?> чел.</td>
					</tr>
					<tr>
						<td>Заработано на рефералах:</td>
						<td class="value"><?=$UserInfo['RefMoney']; ?> руб.</td>
					</tr>
					<tr>
						<td>Переходов по реферальной ссылке:</td>
						<td class="value"><?=$UserInfo['CountHref']; ?> шт.</td>
					</tr>
					
				</table>
            <br><table class="statsTable" style="margin-top:-10px;"><tr><th colspan="2">Список рефералов:</th></tr></table>	
			<table class="tablec">
			<tr class="tablec_trtop"><td>Логин</td><td>Дата</td><td>Пополнено</td><td>Пришёл с...</td></tr>
			
			
			<?
			$r = $mysql->query("SELECT * FROM db_users WHERE RefId = '".$_SESSION['id']."'");
			if($r->rowCount() == 0){
			?>
			<tr><td class="tablec_trnone" colspan="4">У вас нет рефералов</td></tr>		
			<? }else{ 
			while($ref = $r->fetch()){
			
			?>
<tr><td class="tablec_trnone"><?=$ref['Login']; ?></td>	
<td class="tablec_trnone"><?=date("d.m.Yг.",$ref['DateReg']); ?></td>
<td class="tablec_trnone"><?=$ref['MoneyP']; ?></td>
<td class="tablec_trnone"><?=$ref['Href']; ?></td></tr>	

			<? } }?>			
			</table>
			
			
			
			
			
			
			
			
			
			
			