<?


if(!isset($_SESSION['id'])){
		Header("Location: /");
		exit;
}

?>


<div class="holder box grass">
		<div class="info">
		<div style="padding: 10px 10px 10px 50px;">
		Для полной прозрачности проекта, любому игроку предоставляется доступ к полной открытой статистике нашего проекта.
		</div>
		</div>
		<table style="width:100%;"><tr><td style="width:50%;">
		<table class="statsTable"><tr><th colspan="2">Последние пополнения:</th></tr></table>
		<table class="tablec">
			<tr class="tablec_trtop"><td>Логин</td><td>Дата</td><td>Сумма</td></tr>
			<?
		$q = $mysql->query("SELECT * FROM db_enter WHERE Status = 1 ORDER BY Id DESC LIMIT 5");
		while($r = $q->fetch()){
		?>
			<tr class="tablec_trnone"><td><b><?=$r['Login']; ?></b></td><td><?=date("d.m.Y H:i", $r['Date']); ?></td><td><?=$r['Summa']; ?> руб</td></tr>
		<? } ?>	
			
					</table>
		
		</td><td style="width:50%;">
		<table class="statsTable"><tr><th colspan="2">Последние выплаты:</th></tr></table>
		<table class="tablec">
			<tr class="tablec_trtop"><td>Логин</td><td>Дата</td><td>Сумма</td></tr>
			<?
		$q = $mysql->query("SELECT * FROM db_payment WHERE Status = 1 ORDER BY Id DESC LIMIT 5");
		while($r = $q->fetch()){
		?>
			
			<tr class="tablec_trnone"><td><b><?=$r['Login']; ?></b></td><td><?=date("d.m.Y H:i", $r['Date']); ?></td><td><?=$r['Summa']; ?> руб</td></tr>

		<? } ?>
			</table>
		</td></tr></table>
				<table class="statsTable">
					<tr>
						<th colspan="2">Главная информация:</th>
					</tr>
					<tr>
						<td>Дата старта проекта:</td>
						<td class="value"><?=date("d.m.Y", DATESTARTPROJECT); ?></td>
					</tr>
					<tr>
						<td>Время на сервере:</td>
						<td class="value"><?=date("d.m.Y H:i", time()); ?></td>
					</tr>
<?
$t = $mysql->query("SELECT COUNT(Id) AS `UsCount` FROM db_users");
$Users = $t->fetch();
$dd = time() - 86400;
$tt = $mysql->query("SELECT COUNT(Id) AS `UsCountReg` FROM db_users WHERE DateReg > '$dd' ");
$UsersReg = $tt->fetch();
$y = $mysql->query("SELECT SUM(MoneyP) AS `MP` FROM db_users");
$p = $y->fetch();
$yy = $mysql->query("SELECT SUM(MoneyB) AS `MB` FROM db_users");
$py = $yy->fetch();
?>
					<tr>
						<td>Зарегистрировано игроков:</td>
						<td class="value"><?=$Users['UsCount']; ?> чел.</td>
					</tr>
					<tr>
						<td>Зарегистрировано за последние 24 часа:</td>
						<td class="value"><?=$UsersReg['UsCountReg']; ?> чел.</td>
					</tr>
					<tr>
						<td>Всего пополнено игроками:</td>
						<td class="value"><?=$p['MP']; ?> руб.</td>
					</tr>
					<tr>
						<td>Всего выведено игроками:</td>
						<td class="value"><?=$py['MB']; ?> руб.</td>
					</tr>
				</table>
				
		<table style="width:100%;"><tr><td style="width:50%;">
		<table class="statsTable"><tr><th colspan="2">Топ 5 по пополнениям:</th></tr></table>
		<table class="tablec">
			<tr class="tablec_trtop"><td>Логин</td><td>Регистрация</td><td>Сумма</td></tr>
			<?
			$p = $mysql->query("SELECT * FROM db_users ORDER BY MoneyP DESC LIMIT 5");
			while($pp = $p->fetch()){
			?>
			
			<tr class="tablec_trnone"><td><b><?=$pp['Login']; ?></b></td><td><?=date("d.m.Y H:i", $pp['DateReg']); ?></td><td><?=$pp['MoneyP']; ?> руб</td></tr>	
			<? } ?>
			</table>
		
		</td><td style="width:50%;">
		<table class="statsTable"><tr><th colspan="2">Топ 5 по выводу:</th></tr></table>
		<table class="tablec">
			<tr class="tablec_trtop"><td>Логин</td><td>Дата регистрации</td><td>Сумма</td></tr>
			<?
			$p = $mysql->query("SELECT * FROM db_users ORDER BY MoneyB DESC LIMIT 5");
			while($pp = $p->fetch()){
			?>
			<tr class="tablec_trnone"><td><b><?=$pp['Login']; ?></b></td><td><?=date("d.m.Y H:i", $pp['DateReg']); ?></td><td><?=$pp['MoneyB']; ?> руб</td></tr>	
			<? } ?>			
			</table>
		</td></tr></table>
		<table style="width:100%;"><tr><td style="width:50%;">
		<table class="statsTable"><tr><th colspan="2">Топ 5 по рефералам:</th></tr></table>
		<table class="tablec">
			<tr class="tablec_trtop"><td>Логин</td><td>Дата регистрации</td><td>Кол-во</td></tr>
			<?
			$p = $mysql->query("SELECT * FROM db_users ORDER BY CountRef DESC LIMIT 5");
			while($pp = $p->fetch()){
			?>
			<tr class="tablec_trnone"><td><b><?=$pp['Login']; ?></b></td><td><?=date("d.m.Y H:i", $pp['DateReg']); ?></td><td><?=$pp['CountRef']; ?> чел</td></tr>
			<? } ?>
			</table>
		
		</td><td style="width:50%;">
		<table class="statsTable"><tr><th colspan="2">Последние регистрации:</th></tr></table>
		<table class="tablec">
			<tr class="tablec_trtop"><td>Логин</td><td>Дата</td></tr>
			<?
			$p = $mysql->query("SELECT * FROM db_users ORDER BY Id DESC LIMIT 5");
			while($pp = $p->fetch()){
			?>
			<tr class="tablec_trnone"><td><b><?=$pp['Login']; ?></b></td><td><?=date("d.m.Y H:i", $pp['DateReg']); ?></td></tr>
			<? } ?>
			</table>
		</td></tr></table>