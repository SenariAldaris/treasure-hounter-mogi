		<!-- start HOME -->
		<div class="home">
<table style="width:100%;" cellspacing="10"  align="center"><tr><td style="width:100%;" class="home1"><div align="center" class="nametext"><span style="font-size:36px;">КРАТКАЯ СТАТИСТИКА</span></div><br>
<!-- start STATS--><table style="width:100%;font-size:18px;">
<?


$t = $mysql->query("SELECT COUNT(Id) AS `UsCount` FROM db_users");
$Users = $t->fetch();
$dd = time() - 86400;
$tt = $mysql->query("SELECT COUNT(Id) AS `UsCountReg` FROM db_users WHERE DateReg > '$dd' ");
$UsersReg = $tt->fetch();
$y = $mysql->query("SELECT SUM(MoneyP) AS `MP` FROM db_users");
$p = $y->fetch();
$yy = $mysql->query("SELECT SUM(MoneyB) AS `MB` FROM db_users");
$py = $yy->fetch();
?>
<tr>
<td style="padding:7px;border-bottom:1px #e6d3b1 dashed;border-top:1px #e6d3b1 dashed;width:50%;">Всего зарегистрировано:<div style="float:right;"><b><?=$Users['UsCount']; ?> чел.</b></div></td>

<td style="padding:7px;border-left:1px #e6d3b1 dashed;border-bottom:1px #e6d3b1 dashed;border-top:1px #e6d3b1 dashed;width:50%;">Новых за 24 часа:<div style="float:right;"><b><?=$UsersReg['UsCountReg']; ?> чел.</b></div></td>

</tr>
<tr><td style="padding:7px;border-bottom:1px #e6d3b1 dashed;width:50%;">Пополнено пользователями:<div style="float:right;"><b><?=$p['MP']; ?> руб.</b></div></td>

<td style="padding:7px;border-left:1px #e6d3b1 dashed;border-bottom:1px #e6d3b1 dashed;width:50%;">Выведено пользователями:<div style="float:right;"><b><?=$py['MB']; ?> руб.</b></div></td>

</tr>
</table><!-- end STATS -->
</td></tr></table>		

		<table style="width:100%;" cellspacing="10"  align="center"><tr>
		
		<td style="width:50%;" class="home1"><div align="center" class="nametextZ"><span style="font-size:28px;">ПОСЛЕДНИЕ ПОПОЛНЕНИЯ</span></div>
		<div style="margin-top:5px;"><table style="width:100%;">
		<?
		$q = $mysql->query("SELECT * FROM db_enter WHERE Status = 1 ORDER BY Id DESC LIMIT 5");
		while($r = $q->fetch()){
		?>
		<tr style="font-size:18px;">
		<td align="center" style="width:33%;"><?=date("H:i", $r['Date']); ?></td><td align="center" style="width:33%;"><?=$r['Login']; ?></td><td align="center" style="width:33%;"><?=$r['Summa']; ?> руб</td></tr>
		<? } ?>
		
		</table></div>
		</td>
		<td style="width:50%;" class="home1"><div align="center" class="nametextZ"><span style="font-size:28px;">ПОСЛЕДНИЕ ВЫПЛАТЫ</span></div>
		<div style="margin-top:5px;"><table style="width:100%;">
		<?
		$q = $mysql->query("SELECT * FROM db_payment WHERE Status = 1 ORDER BY Id DESC LIMIT 5");
		while($r = $q->fetch()){
		?>
		<tr style="font-size:18px;">
		<td align="center" style="width:33%;"><?=date("H:i", $r['Date']); ?></td><td align="center" style="width:33%;"><?=$r['Login']; ?></td><td align="center" style="width:33%;"><?=$r['Summa']; ?> руб</td></tr>
		<? } ?>
		</table></div>
		</td>
		
		</tr></table>
			
						
			<!-- start COMMISSION -->
			<div class="commission box">
			
				<p class="percentage" style="font-size:28px;font-weight:bold;">15<span>%</span></p>
				<p class="info1"><span>РЕФЕРАЛЬНАЯ СИСТЕМА</span><br />На счет для вывода с каждого пополнения рефералом</p>
			
			</div>
			<!-- end COMMISSION -->
			
			<p class="processors box">АВТОМАТИЧЕСКИЙ ВВОД/ВЫВОД ДЕНЕГ</p>
		
			<div class="clr"></div><br>


			
			<!-- start FEATURES -->
			<ul class="features box">
			<center>
				<li class="one">Тех. поддержка 24/7</li>
				<li class="two">Выделенный сервер</li>
				<li class="three">Открытая группа ВК</li>
				<li class="four">Защита данных</li></center>
			
			</ul>
			<!-- end FEATURES -->
		
		</div>
		<!-- end HOME -->