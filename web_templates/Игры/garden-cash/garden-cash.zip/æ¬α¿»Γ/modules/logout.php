<?

if(!isset($_SESSION['id'])){
		Header("Location: /");
		exit;
}
session_start();
session_destroy();
Header("Location: /");
exit();
?>