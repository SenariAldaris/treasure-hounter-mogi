<?
switch($_GET['page']){
	case 'project': $PageTitle = 'Описание проекта'; break;
	case 'user': $PageTitle = 'Профиль'; break;
	case 'reg': $PageTitle = 'Регистрация в проекте'; break;
	case 'login': $PageTitle = 'Авторизация'; break;
	case 'shop': $PageTitle = 'Магазин саженцев'; break;
	case 'referals': $PageTitle = 'Мои рефералы'; break;
	case '404': $PageTitle = 'Страница не найдена'; break;
	case 'garden': $PageTitle = 'Мой сад'; break;
	case 'insert': $PageTitle = 'Пополнение баланса'; break;
	case 'payment': $PageTitle = 'Вывод средств'; break;
	case 'bonus': $PageTitle = 'Ежедневный бонус'; break;
	case 'cinvestors': $PageTitle = 'Конкурс инвесторов'; break;
	case 'creferals': $PageTitle = 'Конкурс партнеров'; break;
	case 'knb': $PageTitle = 'КНБ'; break;
	case 'knbhistory': $PageTitle = 'История КНБ'; break;
	case 'chat': $PageTitle = 'Онлайн Чат'; break;
	case 'stats': $PageTitle = 'Статистика проекта'; break;
	case 'info': $PageTitle = 'Игровое обучение'; break;
	case 'news': $PageTitle = 'Новости'; break;
	case 'faq': $PageTitle = 'FAQ'; break;
	case 'help': $PageTitle = 'Поддержка'; break;
	case 'trust': $PageTitle = 'Гарантии проекта'; break;
	case 'rules': $PageTitle = 'Правила'; break;
	case 'setting': $PageTitle = 'Настройки аккаунта'; break;
	case 'forgot': $PageTitle = 'Востановление пароля'; break;
	case 'logs': $PageTitle = 'История аккаунта'; break;
	case 'promo': $PageTitle = 'Рекламные материалы'; break;
	case 'bonusp': $PageTitle = 'Бонус на Payeer'; break;
}
?>