<?
ob_start();
session_start();
include("../lib/config.php");
if(!isset($_SESSION['admin'])){
	Header("Location: /admin/login.php");
	exit;
}

include("style/head.php");


if(isset($_GET['page'])){
	$page = clean($_GET['page']);
	switch($page){
		case 'index': include("page/index.php"); break;
		case 'statenter': include("page/statenter.php"); break;
		case 'statvivod': include("page/statvivod.php"); break;
		case 'news': include("page/news.php"); break;
		case 'cp': include("page/cp.php"); break;
		case 'users': include("page/users.php"); break;
		case 'cpinv': include("page/cpinv.php"); break;
		
		
		
		
		default: include("page/404.php"); break;
	}
}else include("page/index.php");


include("style/foot.php");
?>