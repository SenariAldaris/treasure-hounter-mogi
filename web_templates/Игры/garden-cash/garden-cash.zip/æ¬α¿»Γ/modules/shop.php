<?

if(!isset($_SESSION['id'])){
		Header("Location: /");
		exit;
}

?>
<?
if(isset($_GET['id'])){
	$type = intval($_GET['id']);
	if($type >= 1 and $type <= 6){
		switch($type){
			case 1: $pr = $price['price_1']; break;
			case 2: $pr = $price['price_2']; break;
			case 3: $pr = $price['price_3']; break;
			case 4: $pr = $price['price_4']; break;
			case 5: $pr = $price['price_5']; break;
			case 6: $pr = $price['price_6']; break;
		}
		
		if($UserInfo['MoneyIn'] >= $pr){
			$mysql->query("INSERT INTO db_farm SET UserId = '".$_SESSION['id']."', `Type` = '$type', `LastDate` = '".time()."'");
			$mysql->query("UPDATE db_users SET MoneyIn = MoneyIn - '$pr' WHERE Id = '".$_SESSION['id']."'");
			$mysql->query("INSERT INTO db_logs SET UserId = '".$_SESSION['id']."', Text = 'Покупка дерева', Date = '".time()."'");
			echo TextOk('Вы успешно купили дерево!');
		}else echo TextNo("Недостаточно средств на балансе");
	}else echo TextNo('Не выбран тип дерева');
}
?>


<div class="holder box grass">
<div class="info">
		<div style="padding: 10px 10px 10px 50px;">
		В магазине саженцев Вы можете купить саженцы фруктовых растений, всего их шесть. У каждого саженца разная плодовитость и цена.
		</div>
		</div><br>
			<table class="statsTable" style="margin-top:-10px;"><tr><th colspan="2">Ассортимент магазина:</th></tr></table>		
            <table  align="center" style="border-spacing: 0px 35px;">
            <tr><td>
    <div class="pricemagaz">
	<div id="titlemagaz"><h3><b>Вишня</b></h3></div>
	<div class="price_list" style="margin-top: -50px;"><ul class="price_ul">
	<center><li style="font-family:'Open Sans', Arial, sans-serif;font-size:23px;"><b>ПРИБЫЛЬ:</b></li>
	<li><b><?=sprintf("%.2f", ($dohod['full_1'] * 30));?> руб</b> / мес.</li>
	<li><b><?=sprintf("%.2f", ($dohod['full_1']));?> руб</b> / день</li><a href="/shop?id=1&key=873575" class="button green green" style="margin-top:5px;width:120px;">КУПИТЬ ДЕРЕВО</a></center>
	</div>
	<div class="price_img"><img src="../images/image_plan_1.png"> <br/><span class="price_info"><span style="font-size: 16px;border-bottom:1px dashed #2b2b2b;">Цена дерева:</span><div style="margin-top:6px;"><?=$price['price_1'];?> руб.</div></span></div></div><div style="clear: both;"></div>
    </div>
<br><br>	
</td><td>
    <div class="pricemagaz">
	<div id="titlemagaz"><h3><b>Слива</b></h3></div>
	<div class="price_list" style="margin-top: -50px;"><ul class="price_ul">
	<center><li style="font-family:'Open Sans', Arial, sans-serif;font-size:23px;"><b>ПРИБЫЛЬ:</b></li>
	<li><b><?=sprintf("%.2f", ($dohod['full_2'] * 30));?> руб</b> / мес.</li>
	<li><b><?=sprintf("%.2f", ($dohod['full_2']));?> руб</b> / день</li><a href="/shop?id=2&key=873575" class="button green green" style="margin-top:5px;width:120px;">КУПИТЬ ДЕРЕВО</a></center>
	</div>
	<div class="price_img"><img src="../images/image_plan_2.png"> <br/><span class="price_info"><span style="font-size: 16px;border-bottom:1px dashed #2b2b2b;">Цена дерева:</span><div style="margin-top:6px;"><?=$price['price_2'];?> руб.</div></span></div></div><div style="clear: both;"></div>
    </div>
<br><br>	
</td></tr><tr><td>
    <div class="pricemagaz">
	<div id="titlemagaz"><h3><b>Яблоня</b></h3></div>
	<div class="price_list" style="margin-top: -50px;"><ul class="price_ul">
	<center><li style="font-family:'Open Sans', Arial, sans-serif;font-size:23px;"><b>ПРИБЫЛЬ:</b></li>
	<li><b><?=sprintf("%.2f", ($dohod['full_3'] * 30));?> руб</b> / мес.</li>
	<li><b><?=sprintf("%.2f", ($dohod['full_3']));?> руб</b> / день</li><a href="/shop?id=3&key=873575" class="button green green" style="margin-top:5px;width:120px;">КУПИТЬ ДЕРЕВО</a></center>
	</div>
	<div class="price_img"><img src="../images/image_plan_3.png"> <br/><span class="price_info"><span style="font-size: 16px;border-bottom:1px dashed #2b2b2b;">Цена дерева:</span><div style="margin-top:6px;"><?=$price['price_3'];?> руб.</div></span></div></div><div style="clear: both;"></div>
    </div>
<br><br>	
</td><td>
    <div class="pricemagaz">
	<div id="titlemagaz"><h3><b>Персик</b></h3></div>
	<div class="price_list" style="margin-top: -50px;"><ul class="price_ul">
	<center><li style="font-family:'Open Sans', Arial, sans-serif;font-size:23px;"><b>ПРИБЫЛЬ:</b></li>
	<li><b><?=sprintf("%.2f", ($dohod['full_4'] * 30));?> руб</b> / мес.</li>
	<li><b><?=sprintf("%.2f", ($dohod['full_4']));?> руб</b> / день</li><a href="/shop?id=4&key=873575" class="button green green" style="margin-top:5px;width:120px;">КУПИТЬ ДЕРЕВО</a></center>
	</div>
	<div class="price_img"><img src="../images/image_plan_4.png"> <br/><span class="price_info"><span style="font-size: 16px;border-bottom:1px dashed #2b2b2b;">Цена дерева:</span><div style="margin-top:6px;"><?=$price['price_4'];?> руб.</div></span></div></div><div style="clear: both;"></div>
    </div>
<br><br>	
</td></tr><tr><td>
    <div class="pricemagaz">
	<div id="titlemagaz"><h3><b>Груша</b></h3></div>
	<div class="price_list" style="margin-top: -50px;"><ul class="price_ul">
	<center><li style="font-family:'Open Sans', Arial, sans-serif;font-size:23px;"><b>ПРИБЫЛЬ:</b></li>
	<li><b><?=sprintf("%.2f", ($dohod['full_5'] * 30));?> руб</b> / мес.</li>
	<li><b><?=sprintf("%.2f", ($dohod['full_5']));?> руб</b> / день</li><a href="/shop?id=5&key=873575" class="button green green" style="margin-top:5px;width:120px;">КУПИТЬ ДЕРЕВО</a></center>
	</div>
	<div class="price_img"><img src="../images/image_plan_5.png"> <br/><span class="price_info"><span style="font-size: 16px;border-bottom:1px dashed #2b2b2b;">Цена дерева:</span><div style="margin-top:6px;"><?=$price['price_5'];?> руб.</div></span></div></div><div style="clear: both;"></div>
    </div>
<br><br>	
</td><td>
    <div class="pricemagaz">
	<div id="titlemagaz"><h3><b>Апельсин</b></h3></div>
	<div class="price_list" style="margin-top: -50px;"><ul class="price_ul">
	<center><li style="font-family:'Open Sans', Arial, sans-serif;font-size:23px;"><b>ПРИБЫЛЬ:</b></li>
	<li><b><?=sprintf("%.2f", ($dohod['full_6'] * 30));?> руб</b> / мес.</li>
	<li><b><?=sprintf("%.2f", ($dohod['full_6']));?> руб</b> / день</li><a href="/shop?id=6&key=873575" class="button green green" style="margin-top:5px;width:120px;">КУПИТЬ ДЕРЕВО</a></center>
	</div>
	<div class="price_img"><img src="../images/image_plan_6.png"> <br/><span class="price_info"><span style="font-size: 16px;border-bottom:1px dashed #2b2b2b;">Цена дерева:</span><div style="margin-top:6px;"><?=$price['price_6'];?> руб.</div></span></div></div><div style="clear: both;"></div>
    </div>
<br><br>	
</td></tr>            </table>
<link rel="stylesheet" type="text/css" href="../buttons/buttons.css" />
