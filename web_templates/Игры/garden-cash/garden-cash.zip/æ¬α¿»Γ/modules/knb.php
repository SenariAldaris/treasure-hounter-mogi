<?

if(!isset($_SESSION['id'])){
		Header("Location: /");
		exit;
}

if(isset($_POST['sub'])){
	$type = (int)$_POST['type'];
	$sum = sprintf ("%01.2f", str_replace(',', '.', $_POST['sum']));
	
	if($type >= 1 and $type <= 3){
		if($sum >= 1.00){
			if($UserInfo['MoneyP'] >= 50){
				if($UserInfo['MoneyIn'] >= $sum){
					$mysql->query("UPDATE db_users SET MoneyIn = MoneyIn - '$sum' WHERE Id = '".$_SESSION['id']."'");
					$q = $mysql->prepare("INSERT INTO db_knb SET Login = ?, `Type` = ?, `Summa` = ?");
					$q->execute(array($_SESSION['login'], $type, $sum));
					//$lid = $mysql->lastInsertId();
					//$t = $mysql->prepare("INSERT INTO db_knb_history SET UserId = ?, Summa = ?, `Uid` = ?, `Com` = ?");
					//$t->execute(array($_SESSION['id'], $sum, $lid, 'Ожидает'));
					echo TextOk("Ваша игра создана");
				}else echo TextNo("Недостаточно средств на балансе");
			}else echo TextNo("Для того чтобы сделать ставку, необходимо пополнить баланс на 50 руб!");
		}else echo TextNo("Не верная сумма");
	}else echo TextNo("Укажите предмет");
}


if($UserInfo['MoneyP'] < 50){
	echo '<div class="error" style="font-size:22px;text-align:center;">Для того чтобы сделать ставку, необходимо пополнить баланс на 50 руб!</div>';
}


if(isset($_POST['sub2'])){
	$id = (int)$_POST['gmid'];
	$type = (int)$_POST['type'];
	
	if($type >= 1 and $type <= 3){
		$e = $mysql->prepare("SELECT * FROM db_knb WHERE Id = ? AND Status = ?");
		$e->execute(array($id, 0));
		if($e->rowCount() == 1){
			$r = $e->fetch();
			if($r['Login'] != $_SESSION['login']){
				if($r['Summa'] <= $UserInfo['MoneyIn']){
					if($r['Status'] == 0){
						if($r['Type'] == $type){
							//None
							$mysql->query("UPDATE db_users SET MoneyIn = MoneyIn + '".$r['Summa']."' WHERE Login = '".$r['login']."'");
							$mysql->query("UPDATE db_knb SET `Status` = '1' WHERE Id = '$id'");
							$t = $mysql->prepare("INSERT INTO db_knb_h SET Uid = ?, UserId = ?, Login = ?, `Com` = ?");
							$t->execute(array($r['Id'], $_SESSION['id'], $r['Login'], 'Ничья'));
							echo TextOk("Ничья");
						}elseif(($r['Type'] == 1 AND $type == 2) or ($r['Type'] == 2 AND $type == 3) or ($r['Type'] == 3 AND $type == 1)){
							//Loose
							$mysql->query("UPDATE db_users SET MoneyIn = MoneyIn + '".$r['Summa'] + $r['Summa']."' WHERE Login = '".$r['Login']."'");
							$mysql->query("UPDATE db_users SET MoneyIn = MoneyIn - '".$r['Summa']."' WHERE Login = '".$_SESSION['login']."'");
							$mysql->query("UPDATE db_knb SET `Status` = '1' WHERE Id = '$id'");
							$t = $mysql->prepare("INSERT INTO db_knb_h SET Uid = ?, UserId = ?, Login = ?, `Com` = ?");
							$t->execute(array($r['Id'], $_SESSION['id'], $r['Login'], 'Поражение'));
							echo TextOk("Поражение");
						}else{
							//win
							$mysql->query("UPDATE db_users SET MoneyIn = MoneyIn + '".$r['Summa'] + $r['Summa']."' WHERE Login = '".$_SESSION['login']."'");
							//$mysql->query("UPDATE db_users SET MoneyIn = MoneyIn - '".$r['Summa']."' WHERE Login = '".$_SESSION['login']."'");
							$mysql->query("UPDATE db_knb SET `Status` = '1' WHERE Id = '$id'");
							$t = $mysql->prepare("INSERT INTO db_knb_h SET Uid = ?, UserId = ?, Login = ?, `Com` = ?");
							$t->execute(array($r['Id'], $_SESSION['id'], $r['Login'], 'Победа'));
							echo TextOk("Победа");
						}
					}else echo TextNo("Игры не существует");
				}else echo TextNo("Недостаточно средств на балансе");
			}else echo TextNo("Это Ваша ставка! Вы не можете играть сам с собой");
		}else echo TextNo("Игры не существует");
	}else echo TextNo("Укажите предмет");
}
?>









<div class="holder box grass">
				<!-- start LINK -->
		<div class="info">
		<div style="padding: 10px 10px 10px 50px;">
		Камень Ножницы Бумага - легендарная игра которую знает каждый, игра ведется с реальными игроками, правила игры можно прочитать <a href="https://ru.wikipedia.org/wiki/Камень,_ножницы,_бумага" target="_blank">тут</a>.
		</div>
		</div><br>
		<center><a href="/knbhistory" style="border-bottom:1px dashed;font-size:16px;">ИСТОРИЯ ВАШИХ ИГР</a></center>
        <table class="statsTable"><tr><th colspan="2">Условия КНБ:</th></tr></table>
		<div class="sadtext" style="margin-top:10px;">
        Минимальная сумма ставки: <a href="#">1</a> руб.<br>
        Максимальная сумма ставки: <a href="#">100</a> руб.<br>
		Коэффициент выигрыша: <a href="#">х2</a></div><br>
		
        <center>
		<form action="" method="post">
		<div style="border: 1px solid #cDcEDC;border-radius: 5px;font-size: 17px;background-color: rgba(184,243,85,0.3);  width: 400px;"><br>
		
		<TABLE STYLE="WIDTH:100%;MARGIN-TOP:-20PX;">
		<tr>
		<td colspan="3" style="text-align: center;">
		<input type="text" name="sum" value="1.00" style="font-size: 18px; text-align: center;" class="insinput"></td>
		</tr>
		<TR>
		<TD align="center"><input type="radio" name="type" value="1"> КАМЕНЬ<Br></TD>
		<TD align="center"><input type="radio" name="type" value="2"> НОЖНИЦЫ</TD>
		<TD align="center"><input type="radio" name="type" value="3"> БУМАГА</TD>
		</TR></TABLE>
		<div style="margin-top:10px;"><center><input type="submit" class="button green medium" name="sub" value="СДЕЛАТЬ СТАВКУ"/></center>
		</div><br>
		</div></form></center>

			<link rel="stylesheet" type="text/css" href="../buttons/buttons.css" />	
			
			<table class="statsTable"><tr><th colspan="2">Созданые игры:</th></tr></table>
			<table class="tablec">
			<tr class="tablec_trtop"><td>Номер игры</td><td>Логин создателя</td><td>Ставка</td><td>Действие</td></tr>
			<?
			$w = $mysql->query("SELECT * FROM db_knb WHERE `Status` = 0");
			if($w->rowCount() > 0){
			while($s = $w->fetch()){
			?>
			<tr>
			<td class="tablec_trnone" style="font-size:20px;">№<?=$s['Id']; ?></td>
			<td class="tablec_trnone"><a href="" style="font-size:20px;"><?=$s['Login']; ?></a></td>
			<td class="tablec_trnone" style="font-size:20px;"><?=$s['Summa']; ?><br/>РУБ</td>
			<td class="tablec_trnone">
			
			<form action="" method="post">
			<input type="hidden" name="gmid" value="<?=$s['Id']; ?>"/>
			<TABLE align="center"><TR>
			<TD align="center"><input type="radio" name="type" value="1"> КАМЕНЬ<Br></TD>
			<TD align="center"><input type="radio" name="type" value="2"> НОЖНИЦЫ</TD>
			<TD align="center"><input type="radio" name="type" value="3"> БУМАГА</TD>
			<td align="center"><input type="submit" name="sub2" class="button green small" value="ИГРАТЬ!"/></td>
			
			</TR>
			</TABLE>
			
			</form></td></tr>	
			<? } 
			
			}else echo '<tr><td class="tablec_trnone" colspan="4">Нет ставок</td></tr>	';
			
			?>



			
						</table>