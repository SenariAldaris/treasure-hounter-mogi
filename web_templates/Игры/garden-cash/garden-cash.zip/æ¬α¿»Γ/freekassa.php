<?

ob_start();
session_start();
define("PATH", $_SERVER['DOCUMENT_ROOT']);
include_once("DescPage.php");
include_once("lib/config.php");
$merchant_id = $idShopFree;
$merchant_secret = $passShopFree2;
function getIP() {
if(isset($_SERVER['HTTP_X_REAL_IP'])) return $_SERVER['HTTP_X_REAL_IP'];
   return $_SERVER['REMOTE_ADDR'];
}
if (!in_array(getIP(), array('5.9.72.245', '5.9.72.243', '5.9.29.230'))) {
    die("hacking attempt!");
}
$sign = md5($merchant_id.':'.$_REQUEST['AMOUNT'].':'.$merchant_secret.':'.$_REQUEST['MERCHANT_ORDER_ID']);
if ($sign != $_REQUEST['SIGN']) {
    die('wrong sign');
}


			$get_info	= $mysql->query("SELECT * FROM db_enter WHERE Id = ".intval($_REQUEST['MERCHANT_ORDER_ID'])." AND Status != '1' LIMIT 1");
			$row		= $get_info->fetch();
			$user = $mysql->query("SELECT * FROM db_users WHERE Login = '".$row['Login']."'");
			$us = $user->fetch();

			$date = date("d.m.Y");
			if($row['Summa'] >= 100 and $row['Summa'] <= 499){
				$sum = $row['Summa'] + ($row['Summa'] * 0.03);
			}elseif($row['Summa'] >= 500 and $row['Summa'] <= 1499){
				$sum = $row['Summa'] + ($row['Summa'] * 0.06);
			}elseif($row['Summa'] >= 1500 and $row['Summa'] <= 3999){
				$sum = $row['Summa'] + ($row['Summa'] * 0.09);
			}elseif($row['Summa'] >= 4000 and $row['Summa'] <= 9999){
				$sum = $row['Summa'] + ($row['Summa'] * 0.12);
			}elseif($row['Summa'] >= 10000){
				$sum = $row['Summa'] + ($row['Summa'] * 0.15);
			}else{
	$sum = $row['Summa'];
}
			if($row['Summa'] == $_REQUEST['AMOUNT']) {
				$refMoney = $row['Summa'] * $refPerc;
				$mysql->query('UPDATE db_users SET MoneyIn = MoneyIn + '.$sum.', MoneyP = MoneyP + '.$row['Summa'].' WHERE Login = "'.$row['Login'].'" LIMIT 1');
				$mysql->query("UPDATE db_users SET MoneyOut = MoneyOut + '$refMoney', RefMoney = RefMoney + '$refMoney' WHERE Id = '".$us['RefId']."'");
				$mysql->query("UPDATE db_enter SET Status = '1' WHERE Id = ".intval($_REQUEST['MERCHANT_ORDER_ID'])." LIMIT 1");
				//Конкурс рефералов
				include(PATH."/lib/cref.php");
				$c = new competition($mysql);
				$c->UpdatePoints($us['Id'], $row['Summa']);
				//Конкурс инвесторов
				include(PATH."/lib/cinv.php");
				$v = new competitioninv($mysql);
				$v->UpdatePoints($us['Id'], $row['Summa']);
			}else die('wrong Amount');

die('YES');
?>