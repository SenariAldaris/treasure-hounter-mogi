<?

ob_start();
session_start();
include_once("DescPage.php");
include_once("lib/config.php");
if(isset($_GET['ref'])){
	$ref = clean($_GET['ref']);
	$a = cleanUrl($_SERVER['HTTP_REFERER']);
	$mysql->query("UPDATE db_users SET `CountHref` = `CountHref` + '1' WHERE Login = '$ref'");
	setcookie("ref", $ref, time() + 987575, "/");
	setcookie("href", $a, time() + 987575, "/");
	Header("Location: /");
}

include_once("style/head.php");

//Подключаем страници(модули)
if(isset($_GET['page'])) {
	
	$page = clean($_GET['page']);
	
	if(file_exists('modules/'.$page.'.php')){
		
		include_once('modules/'.$page.'.php');
		
	}else{
		
		//include_once("modules/404.php");
		Header("Location: /404");
		
	}
	
}else{
	
	include_once("modules/index.php");
	
}
//Конец

include_once("style/foot.php");





?>


