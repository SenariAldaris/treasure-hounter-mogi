  
  	<div id="rightnow">

				   <div id="box">
                	<h3 id="adduser">Статистика вывода</h3>
					
					     </div> 
<?
if(isset($_POST['ok'])){
	$id = intval($_POST['id']);
	$idU = intval($_POST['idU']);
	$summa = ($_POST['summa']);
	$mysql->query("UPDATE db_payment SET Status = '1' WHERE Id = '$id'");
	$mysql->query("UPDATE db_users SET MoneyB = MoneyB + '$summa' WHERE Id = '$idU'");
}
if(isset($_POST['no'])){
	$id = intval($_POST['id']);
	$mysql->query("UPDATE db_payment SET Status = '2' WHERE Id = '$id'");
}
?> 
 			
		<table border="0" width="100%" cellpadding="0" cellspacing="0" id="product-table">
		
							<tr>
							
                            	<th class="table-header-repeat line-left"><a href="">ID</a></th>
                                <th class="table-header-repeat line-left"><a href="">Логин</a></th>
                                <th class="table-header-repeat line-left"><a href="">Сумма</a></th>
                                <th class="table-header-repeat line-left"><a href="">Кошелек</a></th>
                                <th class="table-header-repeat line-left"><a href="">Система</a></th>
                                <th class="table-header-repeat line-left"><a href="">Дата</a></th>
                                <th class="table-header-repeat line-left"><a href="">Статус</a></th>
                                <th class="table-header-repeat line-left"><a href="">Действие</a></th>
							
                            </tr>

						<tbody>
						<?
$num = 20;  
if(isset($_GET['str'])){
$page = intval($_GET['str']);  
}else{
$page = 1;
}
$result = $mysql->query("SELECT COUNT(*) AS `qaz` FROM db_payment WHERE Status = 0"); 
 $q1 = $result->fetch();
$posts = $q1['qaz'];  
$total = intval(($posts - 1) / $num) + 1;  
$page = intval($page);  
if(empty($page) or $page < 0) $page = 1;  
  if($page > $total) $page = $total;  
$start = $page * $num - $num;  
						$q = $mysql->query("SELECT * FROM db_payment WHERE Status = 0 ORDER BY id DESC LIMIT $start, $num");
						if($q->rowCount() == 0) {
						echo '<tr><td colspan="8">Выводов еще не было</td></tr>';
						}else {
						while($w = $q->fetch()) {
						
							
							if($w['Status'] == 0) {
							$st = 'В Ожидании';
							$color = 'black';
							}elseif($w['Status'] == 1) {
							$st = 'Выплата сделана';
							$color = 'green';
							
							}elseif($w['Status'] == 2){
							$st = 'Выплата отменена';
							$color = 'red';
							}
						?>
							<tr align="center">
                            	<td><?=$w['Id']; ?></td>
                                <td><?=$w['Login']; ?></td>
                                
                                <td><?=$w['Summa']; ?></td>
                                <td><?=$w['Purse']; ?></td>
                                <td><?=$w['PlatSystem']; ?></td>
                               
                                <td><?=date("d.m.Y в H:i:s", $w['Date']); ?></td>
                                <td><font color='<?=$color; ?>'><?=$st; ?></font></td>
								
								
                                <td><form method="post" action="">
								<input type="hidden" name="id" value="<?=$w['Id']; ?>">
								<input type="hidden" name="idU" value="<?=$w['UserId']; ?>">
								<input type="hidden" name="summa" value="<?=$w['Summa']; ?>">
								<input type="submit" name="ok" value="Выплачено">
								</form><br>
								<form method="post" action="">
								<input type="hidden" name="id" value="<?=$w['Id']; ?>">
								<input type="submit" name="no" value="Удалить">
								</form><br></td>
                               
                            </tr>
						<? } }?>
						</tbody>
					</table>
					
					<?
					// Проверяем нужны ли стрелки назад 
if($page >= 1){				
$pervpage='';
$page2left='';
$page1left='';
$page1right='';
$page2right='';
$nextpage='';
}					
if ($page != 1) $pervpage = '<a href= /admin/index.php?admpage=stat_vivod&str=1><<</a>  
                               <a href= /admin/index.php?admpage=stat_vivod&str='. ($page - 1) .'><</a> ';  
// Проверяем нужны ли стрелки вперед  
if ($page != $total) $nextpage = ' <a href= /admin/index.php?admpage=stat_vivod&str='. ($page + 1) .'>></a>  
                                   <a href= /admin/index.php?admpage=stat_vivod&str=' .$total. '>>></a>';  

// Находим две ближайшие станицы с обоих краев, если они есть  
if($page - 2 > 0) $page2left = ' <a href= /admin/index.php?admpage=stat_vivod&str='. ($page - 2) .'>'. ($page - 2) .'</a> | ';
if($page - 1 > 0) $page1left = '<a href= /admin/index.php?admpage=stat_vivod&str='. ($page - 1) .'>'. ($page - 1) .'</a> | ';  
if($page + 2 <= $total) $page2right = ' | <a href= /admin/index.php?admpage=stat_vivod&str='. ($page + 2) .'>'. ($page + 2) .'</a>';
if($page + 1 <= $total) $page1right = ' | <a href= /admin/index.php?admpage=stat_vivod&str='. ($page + 1) .'>'. ($page + 1) .'</a>'; 

// Вывод меню  
echo '<center>'.$pervpage.$page2left.$page1left.'<b>'.$page.'</b>'.$page1right.$page2right.$nextpage.'</center>';  
					?>
  </div>