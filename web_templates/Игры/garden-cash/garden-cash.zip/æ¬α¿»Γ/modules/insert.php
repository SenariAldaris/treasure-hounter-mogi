<?

if(!isset($_SESSION['id'])){
		Header("Location: /");
		exit;
}
?>
<script>
function number_format( number, decimals, dec_point, thousands_sep ) {	// Format a number with grouped thousands
	// 
	// +   original by: Jonas Raoni Soares Silva (http://www.jsfromhell.com)
	// +   improved by: Kevin van Zonneveld (http://kevin.vanzonneveld.net)
	// +	 bugfix by: Michael White (http://crestidg.com)

	var i, j, kw, kd, km;

	// input sanitation & defaults
	if( isNaN(decimals = Math.abs(decimals)) ){
		decimals = 2;
	}
	if( dec_point == undefined ){
		dec_point = ",";
	}
	if( thousands_sep == undefined ){
		thousands_sep = ".";
	}

	i = parseInt(number = (+number || 0).toFixed(decimals)) + "";

	if( (j = i.length) > 3 ){
		j = j % 3;
	} else{
		j = 0;
	}

	km = (j ? i.substr(0, j) + thousands_sep : "");
	kw = i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + thousands_sep);
	//kd = (decimals ? dec_point + Math.abs(number - i).toFixed(decimals).slice(2) : "");
	kd = (decimals ? dec_point + Math.abs(number - i).toFixed(decimals).replace(/-/, 0).slice(2) : "");


	return km + kw + kd;
}

function keyUpSet(id1, id2) {
	var res=document.getElementById(id1).value;
	fb=1;if(res>=100 & res<=499) {
		fb=fb+0.03;
	}
	else if(res>=500 & res<=1499) {
		fb=fb+0.06;
	}
	else if(res>=1500 & res<=3999) {
		fb=fb+0.09;
	}
	else if(res>=4000 & res<=9999) {
		fb=fb+0.12;
	}
	else if(res>=10000) {
		fb=fb+0.15;
	}
	res=number_format(res*fb, 0, ".", " ");
	document.getElementById(id2).innerHTML=res;
}
</script>
<div class="holder box grass">
<div class="info">
		<div style="padding: 10px 10px 10px 50px;">
		Выбирайте наилучший для вас способ пополнения баланса, деньги начисляются на ваш счет сразу после оплаты, некоторые платежные системы могут запрашивать дополнительную комиссию до 5%.
		</div>
		</div>
		<br>
<?
if(isset($_GET['go'])){
	$type = intval($_GET['go']);
	$sum	= sprintf ("%01.2f", str_replace(',', '.', $_POST['sum1']));
	if($sum >= 1){
		if($type >= 1 or $type <= 2){
			$sql = $mysql->prepare("INSERT INTO `db_enter` SET `Login` = ?, `Summa` = ?, `Date` = ?, `Status` = ?");
			$sql->execute(array($_SESSION['login'], $sum, time(), 0));
			$lid = $mysql->lastInsertId();
			
			if($type == 1){
				
				//payeer
					$desc = base64_encode('Popolnene balasa');
					$cu = 'RUB';
					$cid	= $idShopPayeer;
					$m_key	=  $passShopPayeer;
					$arHash = array(
								$cid,
								$lid,
								$sum,
								$cu,
								$desc,
								$m_key
								);

					$sign = strtoupper(hash('sha256', implode(":", $arHash)));

					echo '
						<form method="GET" action="//payeer.com/api/merchant/m.php" accept-charset="utf-8">
						<input type="hidden" name="m_shop" value="'.$cid.'">
						<input type="hidden" name="m_orderid" value="'.$lid.'">
						<input type="hidden" name="m_amount" value="'.$sum.'">
						<input type="hidden" name="m_curr" value="RUB">
						<input type="hidden" name="m_desc" value="'.$desc.'">
						<input type="hidden" name="m_sign" value="'.$sign.'">

						<center>
							
							<p align="center"><input class="button green small" type="submit" name="m_process" value="Оплатить и получить игровую валюту" /></p>
						</center>
						</form>
						';
						
			}
			
			if($type == 2){
				//Freekassa
				$merchant_id = $idShopFree;
				$secret_word = $passShopFree;
				$order_id = $lid;
				$order_amount = $sum;
				$sign = md5($merchant_id.':'.$order_amount.':'.$secret_word.':'.$order_id);
				?>
				<form method='get' action='http://www.free-kassa.ru/merchant/cash.php'>
					<input type='hidden' name='m' value='<?=$merchant_id;?>'>
					<input type='hidden' name='oa' value='<?=$order_amount;?>'>
					<input type='hidden' name='o' value='<?=$lid;?>'>
					<input type='hidden' name='s' value='<?=$sign;?>'>
					
					<input type='hidden' name='lang' value='ru'>
					
					<input type='submit' class="button green small" name='pay' value='Оплатить и получит игровую валюту'>
				</form>
<?
			}
		}else echo TextNo("Укажите платежную систему");
	}else echo TextNo("Минимальная сумма 1 руб");
?>
<link rel="stylesheet" type="text/css" href="../buttons/buttons.css" />

<?

}else{
?>
		<center><div class="instable">
<table style="width:100%;"><tr><td style="width:250px;" align="center">
<img src="/images/payeer_insert.png"></td>
<td style="font-size:18px;">Payeer, Qiwi, Яндекс.Деньги, Liqpay, W1, Egopay, E-BTC, Мтс, Мегафон, Okpay, Paxum, Visa, Maestro, Терминалы оплаты</td>
</tr></table>
<form action="/insert?go=1" method="post">
<table style="width:100%;font-size:18px;"><tr>
<td align="right" style="width:50%;">Сумма пополнения: <input type="text" id="setnum" name="sum1" value="100" style="font-size: 18px;" class="insinput" onkeyup="keyUpSet('setnum', 'numval');"> Руб.</td><td align="left" style="width:50%;padding:3px;"><center><input type="submit" class="button green small" value="ПОПОЛНИТЬ СЧЕТ"/></center>
</td></tr></table></form>
Вы получите <span id="numval">100</span> руб. с учетом <a href="/bonuses" style="color:#d22;border-bottom:1px dashed #d22;">бонусов</a>
</div></center>
<br>
<center><div class="instable">
<table style="width:100%;"><tr><td style="width:250px;" align="center">
<img src="/images/free_insert.png"></td>
<td style="font-size:18px;">Qiwi, Яндекс.Деньги, Терминалы, Ooopay, Bitcoin, W1, Мтс, Мегафон, Perfect Money, Okpay, Egopay, Z-Payment Visa, MasterCard</td>
</tr></table>
<form action="/insert?go=2" method="post">
<table style="width:100%;font-size:18px;"><tr>
<td align="right" style="width:50%;">Сумма пополнения: <input type="text" id="setnum2" name="sum1" value="100" style="font-size: 18px;" class="insinput" onkeyup="keyUpSet('setnum2', 'numval2');"> Руб.</td><td align="left" style="width:50%;padding:3px;"><center><input type="submit" class="button green small" value="ПОПОЛНИТЬ СЧЕТ"/></center>
</td></tr></table></form>
Вы получите <span id="numval2">100</span> руб. с учетом <a href="/bonuses" style="color:#d22;border-bottom:1px dashed #d22;">бонусов</a>
</div></center>
<br>
<center><div class="instable">
<table style="width:100%;"><tr><td style="width:250px;" align="center">
<img src="../images/webmoney_ico.png"></td>
<td style="font-size:18px;">Ручное пополнение через платежную систему WebMoney. <span style="color:#d22;">Срок зачисления от 5 минут до получаса</span>, ночью/утром возможны задержки до 4-6 часов.</td>
</tr>
<tr><td style="width:100%;" colspan="2"><span style="font-size:18px;">Для пополнения счета через WebMoney переведите любую денежную сумму от 10 рублей/центов на кошельки:</span><br>

<p style="font-size:22px;color:#c53939;font-family:cuprum;"><b><img src="/images/rub.png">&nbsp;<?=$wmr; ?> <span style="color:#000;">(Рубли)</span> <br><img src="/images/usd.png">&nbsp;<?=$wmz; ?> <span style="color:#000;">(Доллары)</span> <br><img src="/images/eur.png">&nbsp;<?=$wme; ?> <span style="color:#000;">(Евро)</span></b></p>
<div class="sadtext"><span style="color:#c53939;">Обязательно!!!</span> Укажите в примечании к переводу &nbsp;" Мой логин <?=$_SESSION['login']; ?> "&nbsp;</div>
<hr>Деньги зачисленные на долларовые и евро кошельки будут переведены в рубли на проекте по курсу ЦБ РФ. При длительной задержке платежа обращайтесь в тех. поддержку!
</td></tr>

</table>
</div></center>
<link rel="stylesheet" type="text/css" href="../buttons/buttons.css" />
<? } ?>