<script type="text/javascript" src="/admin/js/ckeditor/ckeditor.js"></script>
                    <h3>Новости</h3> 
	
	<?
	if(isset($_GET['dell'])){
		$id = intval($_GET['dell']);
		$mysql->query("DELETE FROM db_news WHERE Id = '$id'");
		Header("Refresh: 1, /admin/index.php?page=news");
		return;
		
	}
	
	
	
	
	if(isset($_POST['save1'])) {
	$title = clean($_POST['title']);
	$text = $_POST['text'];
	$id_n = intval($_POST['id_n']);
	//mysql_query("INSERT INTO tb_news (`title`, `text`, `date`) VALUES ('$title', '$text', '".time()."')") or die(mysql_error());
	$mysql->query("UPDATE db_news SET `Title` = '$title', `Text` = '$text' WHERE Id = '$id_n'");
	echo '<center><font color="green">Новость обновлена</font></center>';
					Header("Refresh: 2, /admin/index.php?page=news");
	}
	
	
	if(isset($_GET['read'])) {
	$id = intval($_GET['read']);
	$qq = $mysql->query("SELECT * FROM db_news WHERE Id = '$id'");
	$q = $qq->fetch();
	?>
	<form id="form1" name="form1" method="post" action="">
	<input type="hidden" name="id_n" value="<?=$q['Id'];?>">
	<table border="0" width="100%" cellpadding="0" cellspacing="0" id="product-table">
	<tr>
	<td style="width:100px;">Название новости</td><td><input type="text" name="title" value="<?=$q['Title']; ?>" /></td>
	</tr>
	<tr>
	<td  style="width:100px;">Текст новости</td><td>
<textarea name="text" id="editor1" cols="45" rows="5"><?=$q['Text']; ?></textarea></td>
</tr>
<tr><td colspan="2"><input type="submit" name="save1" value="Обновить"></td></tr>
<script type="text/javascript">
CKEDITOR.replace( 'editor1');
</script>

</table>
	</form>
	
	
	
	
	<?
	return;
	}
	
	
	
	if(isset($_POST['save'])) {
	$title = $_POST['title'];
	$text = $_POST['text'];
	$mysql->query("INSERT INTO db_news (`Title`, `Text`, `Date`) VALUES ('$title', '$text', '".time()."')");
	echo '<center><font color="green">Новость добавлена</font></center>';
					Header("Refresh: 2, /admin/index.php?page=news");
	}
	
	
	if(isset($_GET['add'])) {
	?>
	<form id="form1" name="form1" method="post" action="">
	<table align="center">
	<tr>
	<td style="width:100px;">Название новости</td><td><input type="text" name="title"></td>
	</tr>
	<tr>
	<td  style="width:100px;">Текст новости</td><td>
<textarea name="text" id="editor1" cols="45" rows="5"></textarea></td>
</tr>
<tr><td colspan="2"><input type="submit" name="save" value="Добавить"></td></tr>
<script type="text/javascript">
CKEDITOR.replace( 'editor1');
</script>

</table>
	</form>
	
	<?
	return;
	}
	?>
	
	
					<br><hr><br>					
					<a href="/admin/index.php?page=news&add=add">Добавить новость</a>	
	
					<br><br><hr>					
				  <table border="0" width="100%" cellpadding="0" cellspacing="0" id="product-table">
						
							<tr>
                            	<th class="table-header-repeat line-left"><a href="">ID</a></th>
                                <th class="table-header-repeat line-left"><a href="">Название</a></th>
                                <th class="table-header-repeat line-left"><a href="">Действие</a></th>
                            </tr>
						
						<tbody>
						<?
						$q = $mysql->query("SELECT * FROM db_news ORDER BY Id DESC");
						while($w = $q->fetch()) {
						?>
							<tr align="center">
                            	<td><?=$w['Id']; ?></td>
                                <td><?=$w['Title']; ?></td>
                                
                                <td>

								<a href="/admin/index.php?page=news&read=<?=$w['Id']; ?>" class="icon-1 info-tooltip"></a>
								<a href="/admin/index.php?page=news&dell=<?=$w['Id']; ?>" class="icon-2 info-tooltip"></a>
								</td>
                            </tr>
						<? } ?>
						</tbody>
					</table>
					
					
					<br><hr><br>
					
