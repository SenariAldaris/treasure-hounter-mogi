  
  	<div id="rightnow">

				   <div id="box">
                	<h3 id="adduser">Статистика пополнений</h3>
					
					     </div> 
  
  <table border="0" width="100%" cellpadding="0" cellspacing="0" id="product-table">
						
							<tr>
                            	<th class="table-header-repeat line-left"><a href="">ID</a></th>
                                <th class="table-header-repeat line-left"><a href="">Логин</a></th>
                                <th class="table-header-repeat line-left"><a href="">Сумма</a></th>
                                
                                <th class="table-header-repeat line-left"><a href="">Дата</a></th>

                            </tr>
						
						<tbody>
						<?
$num = 20;  
if(isset($_GET['str'])){
$page = intval($_GET['str']);  
}else{
$page = 1;
}  
$result = $mysql->query("SELECT COUNT(*) AS `qw`  FROM db_enter WHERE Status = 1");  
$q1 = $result->fetch();
$posts = $q1['qw'];  
$total = intval(($posts - 1) / $num) + 1;  
$page = intval($page);  
if(empty($page) or $page < 0) $page = 1;  
  if($page > $total) $page = $total;  
$start = $page * $num - $num;  
						$q = $mysql->query("SELECT * FROM db_enter WHERE Status = 1 ORDER BY Id DESC LIMIT $start, $num");
						if($q->rowCount() == 0) {
						echo '<tr><td colspan="4">Пополнений еще не было</td></tr>';
						}else {
						while($w = $q->fetch()) {
						?>
							<tr align="center">
                            	<td><?=$w['Id']; ?></td>
                                <td><?=$w['Login']; ?></td>
                                <td><?=$w['Summa']; ?></td>
                                
                                <td><?=date("d.m.Y в H:i:s", $w['Date']); ?></td>
                               
                            </tr>
						<? } }?>
						</tbody>
					</table>
					
					<?
					// Проверяем нужны ли стрелки назад  
					if($page >= 1){				
$pervpage='';
$page2left='';
$page1left='';
$page1right='';
$page2right='';
$nextpage='';
}				
if ($page != 1) $pervpage = '<a href= /admin/index.php?admpage=stat_enter&str=1><<</a>  
                               <a href= /admin/index.php?admpage=stat_enter&str='. ($page - 1) .'><</a> ';  
// Проверяем нужны ли стрелки вперед  
if ($page != $total) $nextpage = ' <a href= /admin/index.php?admpage=stat_enter&str='. ($page + 1) .'>></a>  
                                   <a href= /admin/index.php?admpage=stat_enter&str=' .$total. '>>></a>';  

// Находим две ближайшие станицы с обоих краев, если они есть  
if($page - 2 > 0) $page2left = ' <a href= /admin/index.php?admpage=stat_enter&str='. ($page - 2) .'>'. ($page - 2) .'</a> | ';  
if($page - 1 > 0) $page1left = '<a href= /admin/index.php?admpage=stat_enter&str='. ($page - 1) .'>'. ($page - 1) .'</a> | ';  
if($page + 2 <= $total) $page2right = ' | <a href= /admin/index.php?admpage=stat_enter&str='. ($page + 2) .'>'. ($page + 2) .'</a>';  
if($page + 1 <= $total) $page1right = ' | <a href= /admin/index.php?admpage=stat_enter&str='. ($page + 1) .'>'. ($page + 1) .'</a>'; 

// Вывод меню  
echo '<center>'.$pervpage.$page2left.$page1left.'<b>'.$page.'</b>'.$page1right.$page2right.$nextpage.'</center>';  
					?>
  </div>