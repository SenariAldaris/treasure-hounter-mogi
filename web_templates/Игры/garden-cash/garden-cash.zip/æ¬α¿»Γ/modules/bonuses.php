<div class="holder box grass">
		<div class="info">
		<div style="padding: 10px 10px 10px 50px;">
		Для участников проекта администрация подготовила ряд акций, бонусов, конкурсов и заданий благодаря которым все игроки могут получить дополнительный доход, следите за обновлениями!
		</div>
		</div>

		<table class="statsTable"><tr><th colspan="2">Бонусы:</th></tr></table>
		<br><CENTER><SPAN style="color:green;font-size:21px;">ВНИМАНИЕ! ВСЕ БОНУСЫ НА ПОПОЛНЕНИЕ <b>СУММИРУЮТСЯ</b>!</SPAN></CENTER><br>
<center><div class="timetable">
<div class="sadtext">Бонус на пополнение</div>
<span style="font-size:16px;text-align:left;">Бонус на пополнение каждому игроку, сумма бонуса напрямую зависит от суммы вашего пополнения.</span>
<div class="sadtext" style="margin-top:-10px;text-align:left;">
<br>При пополнении от <a href="#">100 руб.</a> до <a href="#">499 руб.</a> бонус - <a href="#">3%</a>
<br>При пополнении от <a href="#">500 руб.</a> до <a href="#">1499 руб.</a> бонус - <a href="#">6%</a>
<br>При пополнении от <a href="#">1500 руб.</a> до <a href="#">3999 руб.</a> бонус - <a href="#">9%</a>
<br>При пополнении от <a href="#">4000 руб.</a> до <a href="#">9999 руб.</a> бонус - <a href="#">12%</a>
<br>При пополнении от <a href="#">10000 руб.</a> бонус - <a href="#">15%</a>
</div>
</div></center>
		<br>
<center><div class="timetable">
<div class="sadtext">Бонус новичкам на пополнение</div>
<span style="font-size:16px;">В течении 3 дней после регистрации действует бонус на все пополнения новыми игроками - 10% от суммы пополнения.</span>
</div></center>
		<br>
<center><div class="timetable">
<div class="sadtext">Бонус новичкам</div>
<span style="font-size:16px;">10 рублей, а так же одно дерево "Вишня" в подарок сразу после регистрации каждому игроку!</span>
</div></center>