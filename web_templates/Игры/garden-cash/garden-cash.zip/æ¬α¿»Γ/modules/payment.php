<?

if(!isset($_SESSION['id'])){
		Header("Location: /");
		exit;
}

?>
<script>
function number_format( number, decimals, dec_point, thousands_sep ) {	// Format a number with grouped thousands
	// 
	// +   original by: Jonas Raoni Soares Silva (http://www.jsfromhell.com)
	// +   improved by: Kevin van Zonneveld (http://kevin.vanzonneveld.net)
	// +	 bugfix by: Michael White (http://crestidg.com)

	var i, j, kw, kd, km;

	// input sanitation & defaults
	if( isNaN(decimals = Math.abs(decimals)) ){
		decimals = 2;
	}
	if( dec_point == undefined ){
		dec_point = ",";
	}
	if( thousands_sep == undefined ){
		thousands_sep = ".";
	}

	i = parseInt(number = (+number || 0).toFixed(decimals)) + "";

	if( (j = i.length) > 3 ){
		j = j % 3;
	} else{
		j = 0;
	}

	km = (j ? i.substr(0, j) + thousands_sep : "");
	kw = i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + thousands_sep);
	//kd = (decimals ? dec_point + Math.abs(number - i).toFixed(decimals).slice(2) : "");
	kd = (decimals ? dec_point + Math.abs(number - i).toFixed(decimals).replace(/-/, 0).slice(2) : "");


	return km + kw + kd;
}

function keyUpSet(id1, id2) {
	var res=document.getElementById(id1).value;
	fb=1.1;
	res=number_format(res*fb, 2, ".", " ");
	document.getElementById(id2).value=res;
}
</script>

<?
if(isset($_POST['obmen'])){
	$sum	= sprintf ("%01.2f", str_replace(',', '.', $_POST['exsum']));
	if($sum >= 1){
		if($UserInfo['MoneyOut'] >= $sum){
			$sump = $sum + ($sum * 0.1);
			$mysql->query("UPDATE db_users SET MoneyIn = MoneyIn + '$sump', MoneyOut = MoneyOut - '$sum' WHERE Id = '".$_SESSION['id']."'");
			echo TextOk("Успешный обмен");
		}else echo TextNo("Недостаточно средств на балансе");
	}else echo TextNo("Не верная сумма обмена");
}


if(isset($_GET['get'])){
	$get = (int)$_GET['get'];
	$purse = clean($_POST['purse']);
	$summa = sprintf ("%01.2f", str_replace(',', '.', $_POST['sum']));
	$code = clean($_POST['code']);
	if(!empty($purse) and !empty($summa) and !empty($code)) {
		if($code == $UserInfo['PlatPass']) {
			if($UserInfo['MoneyOut'] >= $summa){
				if($get >= 1 and $get <= 3){
					if($get == 1){
						//Payeer
						$MinOut = 0.1;
						$ps = 'Payeer';
					}elseif($get == 2){
						//Yandex
						$MinOut = 10;
						$ps = 'Yandex';
					}elseif($get == 3){
						//Qiwi
						$MinOut = 20;
						$ps = 'Qiwi';
					}
						if($summa >= $MinOut){
							if($get == 1){
							include($_SERVER['DOCUMENT_ROOT']."/lib/cpayeer.php");
							$payeer = new CPayeer($PurseAPIPayeer, $idAPIPayeer, $passAPIPayeer);
                            if ($payeer->isAuth())
                            {
                          
                                $arBalance = $payeer->getBalance();
								//var_dump($arBalance);
								$bal = $arBalance["balance"]["RUB"]["DOSTUPNO"];
								if($bal >= 0) {
								 $arTransfer = $payeer->transfer(array(
                                    'curIn' => 'RUB', // счет списани¤
                                    'sum' => $summa, // сумма получени¤
                                    'curOut' => 'RUB', // валюта получени¤
                                    'to' => $purse, // получатель (email)
                                  
                                    'comment' => 'Выплата с сайта '.SITENAE
                                   
                                    ));
									if (empty($arTransfer['errors']) && $arTransfer['historyId'] > 0)
									{
										$mysql->query("UPDATE db_users SET MoneyOut = MoneyOut - '$summa', MoneyB = MoneyB + '$summa' WHERE Id = '".$_SESSION['id']."'");
										$w = $mysql->prepare("INSERT INTO db_payment SET Login = ?, UserId = ?, Summa = ?, Purse = ?, PlatSystem = ?, Date = ?, Status = ?");
										$w->execute(array($_SESSION['login'], $_SESSION['id'], $summa, $purse, $ps, time(), 1));
										echo TextOk("Заявка на вывод средств отправлена!");
										
									}
									else
									{
										echo '<pre>'.print_r($arTransfer["errors"], true).'</pre>';		
									}
									
								}
									
							}else{
									echo '<pre>'.print_r($payeer->getErrors(), true).'</pre>';
								}
								

							}elseif($get == 2){
								include($_SERVER['DOCUMENT_ROOT']."/lib/cpayeer.php");
								$payeer = new CPayeer($PurseAPIPayeer, $idAPIPayeer, $passAPIPayeer);
								if ($payeer->isAuth())
								{
									$initOutput = $payeer->initOutput(array(
										'ps' => '25344', //Yandex
										//'sumIn' => 1,        
										'curIn' => 'RUB',
										'sumOut' => $summa, 
										'curOut' => 'RUB',  
										'param_ACCOUNT_NUMBER' => $purse
									));
									
									if ($initOutput)
									{
										$historyId = $payeer->output();
										if ($historyId > 0)
										{
											$mysql->query("UPDATE db_users SET MoneyOut = MoneyOut - '$summa', MoneyB = MoneyB + '$summa' WHERE Id = '".$_SESSION['id']."'");
										$w = $mysql->prepare("INSERT INTO db_payment SET Login = ?, UserId = ?, Summa = ?, Purse = ?, PlatSystem = ?, Date = ?, Status = ?");
										$w->execute(array($_SESSION['login'], $_SESSION['id'], $summa, $purse, $ps, time(), 1));
								echo TextOk("Заявка на вывод средств отправлена!");
										}
										else
										{
											echo '<pre>'.print_r($payeer->getErrors(), true).'</pre>';
										}
									}
									else
									{
										echo '<pre>'.print_r($payeer->getErrors(), true).'</pre>';
									}
								}
								else
								{
									echo '<pre>'.print_r($payeer->getErrors(), true).'</pre>';
								}
								
							}elseif($get == 3){
								include($_SERVER['DOCUMENT_ROOT']."/lib/cpayeer.php");
								$payeer = new CPayeer($PurseAPIPayeer, $idAPIPayeer, $passAPIPayeer);
								if ($payeer->isAuth())
								{
									$initOutput = $payeer->initOutput(array(
										'ps' => '60792237', //Qiwi
										//'sumIn' => 1,        
										'curIn' => 'RUB',
										'sumOut' => $summa, 
										'curOut' => 'RUB',  
										'param_ACCOUNT_NUMBER' => $purse
									));
									
									if ($initOutput)
									{
										$historyId = $payeer->output();
										if ($historyId > 0)
										{
											$mysql->query("UPDATE db_users SET MoneyOut = MoneyOut - '$summa', MoneyB = MoneyB + '$summa' WHERE Id = '".$_SESSION['id']."'");
										$w = $mysql->prepare("INSERT INTO db_payment SET Login = ?, UserId = ?, Summa = ?, Purse = ?, PlatSystem = ?, Date = ?, Status = ?");
										$w->execute(array($_SESSION['login'], $_SESSION['id'], $summa, $purse, $ps, time(), 1));
								echo TextOk("Заявка на вывод средств отправлена!");
										}
										else
										{
											echo '<pre>'.print_r($payeer->getErrors(), true).'</pre>';
										}
									}
									else
									{
										echo '<pre>'.print_r($payeer->getErrors(), true).'</pre>';
									}
								}
								else
								{
									echo '<pre>'.print_r($payeer->getErrors(), true).'</pre>';
								}
								
							}
						}else echo TextNo("Минимум для выплаты ".$MinOut);
				}else echo TextNo("Укажите платежную систему");
			}else echo TextNo("Не достаточно средств на балансе");
		}else echo TextNo("Не верный платежный пароль");
	}else echo TextNo("Заполнены не все поля");
}




?>
<!-- start HOLDER -->
			<div class="holder box grass">
			<?
			if(isset($_GET['exchange'])){
			?>
			<center><div class="instable">
<table style="width:100%;"><tr><td style="width:250px;" align="center">
<div class="sadtext">ОБМЕН <a href="#">ВЫВОД -> ПОКУПКИ</a></div>
<img src="../images/exchange_ico.png"></td><td>
<form action="/payment?get=4" method="post">
<table><tr>
<td><div class="sadtext">Сумма обмена: <span style="color:#c53939;">(МИН. 1 РУБ.)</span></div><input type="text" id="setnum" name="exsum" value="1.00" style="font-size: 22px;height: auto;width:200px;" class="insinput" onkeyup="keyUpSet('setnum', 'numval');"></td>
</tr>
<tr>
<td><div class="sadtext">Сумма получения: <span style="color:#c53939;">(+10%)</span></div><input type="text" disabled="disabled" id="numval" value="1.10" style="font-size: 22px;height: auto;width:200px;" class="insinput"></td>
</tr></table>
</td></tr></table><BR>
<center><input type="submit" name="obmen" class="button green small" value="ОБМЕНЯТЬ СРЕДСТВА"/></center>
</form>
</div></center><link rel="stylesheet" type="text/css" href="../buttons/buttons.css" />






			<? } elseif(isset($_GET['payeer'])) {?>		
			
			
			
			
			
			<center><div class="instable">
<table style="width:100%;"><tr><td style="width:250px;" align="center">
<div class="sadtext">ВЫПЛАТА НА <a href="http://payeer.com/">PAYEER</a></div>
<img src="../images/payeer_ico.png"></td><td>
<form action="/payment?payeer&get=1" method="post"><table>
<tr><td>
<div class="sadtext">Номер кошелька PAYEER:</div><input type="text" name="purse" placeholder="P12345678" style="font-size: 22px;height: auto;width:200px;" class="insinput"></td></tr><tr><td><div class="sadtext">Сумма для вывода: <span style="color:#c53939;">(мин. 0,1 руб.)</span></div><input type="text" name="sum" value="<?=$UserInfo['MoneyOut']; ?>" style="font-size: 22px;height: auto;width:200px;" class="insinput"></td></tr></table>
</td></tr></table><BR>
<center><input type="submit" class="button green small" value="ЗАКАЗАТЬ ВЫПЛАТУ"/></center>
<?
if($UserInfo['PlatPass'] == ''){
?>
<p><center><div class="sadtext" style="color:#c53939;">ВНИМАНИЕ!!! <a href="/setting" style="border-bottom:1px green dashed;">ПЛАТЕЖНЫЙ ПАРОЛЬ</a> НЕ УСТАНОВЛЕН! ВЫПЛАТЫ НЕВОЗМОЖНЫ!</div></center></p>
<? } else { ?>
<center><p><span style="font-size:18px;font-family:cuprum;"><B>ПЛАТЕЖНЫЙ ПАРОЛЬ:</B></span> <input type="password" name="code" placeholder="*******" style="width:70px;font-size: 18px;" class="insinput"></p></center>
<? } ?>
</form></div></center><link rel="stylesheet" type="text/css" href="../buttons/buttons.css" />



			<? } elseif(isset($_GET['yandex'])) {?>
			
			
			
						<center><div class="instable">
<table style="width:100%;"><tr><td style="width:250px;" align="center">
<div class="sadtext">ВЫПЛАТА НА <a href="http://money.yandex.ru/">ЯНДЕКС.ДЕНЬГИ</a></div>
<img src="../images/yandex_ico.png"></td><td>
<form action="/payment?yandex&get=2" method="post"><table><tr><td><div class="sadtext">Номер кошелька Яндекс.Деньги:</div><input type="text" name="purse" placeholder="410011663509580" style="font-size: 22px;height: auto;width:200px;" class="insinput"></td></tr><tr><td><div class="sadtext">Сумма для вывода: <span style="color:#c53939;">(мин. 10 руб.)</span></div><input type="text" name="sum" value="<?=$UserInfo['MoneyOut']; ?>" style="font-size: 22px;height: auto;width:200px;" class="insinput"></td></tr></table>
</td></tr></table><BR>
<center><input type="submit" class="button green small" value="ЗАКАЗАТЬ ВЫПЛАТУ"/></center>
<?
if($UserInfo['PlatPass'] == ''){
?>
<p><center><div class="sadtext" style="color:#c53939;">ВНИМАНИЕ!!! <a href="/setting" style="border-bottom:1px green dashed;">ПЛАТЕЖНЫЙ ПАРОЛЬ</a> НЕ УСТАНОВЛЕН! ВЫПЛАТЫ НЕВОЗМОЖНЫ!</div></center></p>
<? } else { ?>
<center><p><span style="font-size:18px;font-family:cuprum;"><B>ПЛАТЕЖНЫЙ ПАРОЛЬ:</B></span> <input type="password" name="code" placeholder="*******" style="width:70px;font-size: 18px;" class="insinput"></p></center>
<? } ?></form></div></center><link rel="stylesheet" type="text/css" href="../buttons/buttons.css" />



			<? } elseif(isset($_GET['qiwi'])) { ?>
			
			
			
			<center><div class="instable">
<form action="/payment?qiwi&get=3" method="post"><table style="width:100%;"><tr><td style="width:250px;" align="center">
<div class="sadtext">ВЫПЛАТА НА <a href="http://qiwi.ru/">QIWI Кошелек</a></div>
<img src="../images/qiwi_ico.png"></td><td>
<table><tr><td><div class="sadtext">Номер кошелька QIWI:</div><input name="purse" type="text" placeholder="+7..." style="font-size: 22px;height: auto;width:200px;" class="insinput"></td></tr><tr><td><div class="sadtext">Сумма для вывода: <span style="color:#c53939;">(мин. 20 руб.)</span></div><input type="text" name="sum" value="<?=$UserInfo['MoneyOut']; ?>" style="font-size: 22px;height: auto;width:200px;" class="insinput"></td></tr></table>
</td></tr></table><BR>
<center><input type="submit" class="button green small" value="ЗАКАЗАТЬ ВЫПЛАТУ"/></center><?
if($UserInfo['PlatPass'] == ''){
?>
<p><center><div class="sadtext" style="color:#c53939;">ВНИМАНИЕ!!! <a href="/setting" style="border-bottom:1px green dashed;">ПЛАТЕЖНЫЙ ПАРОЛЬ</a> НЕ УСТАНОВЛЕН! ВЫПЛАТЫ НЕВОЗМОЖНЫ!</div></center></p>
<? } else { ?>
<center><p><span style="font-size:18px;font-family:cuprum;"><B>ПЛАТЕЖНЫЙ ПАРОЛЬ:</B></span> <input type="password" name="code" placeholder="*******" style="width:70px;font-size: 18px;" class="insinput"></p></center>
<? } ?></form>
</div></center><link rel="stylesheet" type="text/css" href="../buttons/buttons.css" />


			<? }else{?>
			
			
			<div class="sadtext">Выберите платежную систему:</div><br>
<table style="width:100%;border-spacing: 0px 30px;"><tr>

<td align="center" style="width:33%;"><div class="sadtext" style="color:#c53939;">Минимум: 0,1 руб.</div><img src="../images/payeer_ico.png"><br><a href="/payment?payeer" class="button green small">ЗАКАЗАТЬ ВЫПЛАТУ</a></td>

<td align="center" style="width:33%;"><div class="sadtext" style="color:#c53939;">Минимум: 10 руб.</div><img src="../images/yandex_ico.png"><br><a href="/payment?yandex" class="button green small">ЗАКАЗАТЬ ВЫПЛАТУ</a></td>

<td align="center" style="width:33%;"><div class="sadtext" style="color:#c53939;">Минимум: 20 руб.</div><img src="../images/qiwi_ico.png"><br><a href="/payment?qiwi" class="button green small">ЗАКАЗАТЬ ВЫПЛАТУ</a></td>

</tr><tr>

<td align="center" style="width:33%;"><div class="sadtext" style="color:#c53939;">Минимум: 1 руб.</div><img src="../images/exchange_ico.png"><br><a href="/payment?exchange" class="button orange small">ОБМЕНЯТЬ ВАЛЮТУ</a></td>

<td align="center" style="width:33%;"><div class="sadtext" style="color:#c53939;">Минимум: 10 руб.</div><img src="../images/bitcoin_ico.png"><br><a href="#" class="button gray small">ВРЕМЕННО НЕДОСТУПНО!</a></td>

<td align="center" style="width:33%;"><div class="sadtext" style="color:#c53939;">Минимум: 10 руб.</div><img src="../images/webmoney_ico.png"><br><a href="#" class="button gray small">ВРЕМЕННО НЕДОСТУПНО!</a></td>

</tr></table>
<link rel="stylesheet" type="text/css" href="../buttons/buttons.css" />
			<? } ?>
<br><br><div class="sadtext">Последние 10 выплат:</div>
<table cellpadding="3" cellspacing="0" align="center" width="100%" class="tablec">
<tr align="center" class="tablec_trtop">
	<td title="Платежная система">PS</td>
	<td>Номер Счета</td>
	<td>Дата выплаты</td>
	<td>Сумма РУБ</td>
	<td>Статус</td>
</tr>
<?
$q = $mysql->query("SELECT * FROM db_payment WHERE UserId = '".$_SESSION['id']."'");
if($q->rowCount() == 0){
?>
<tr align="center" class="tablec_trnone"><td colspan="5">Вы еще не совершали выплаты.</td></tr>
<? 

} else {
	while($r = $q->fetch())
	{
		if($r['Status'] == 1) $st = 'Выплачено';
	?>
	
	<tr align="center" class="tablec_trtop">
	<td title="Платежная система"><?=$r['PlatSystem']; ?></td>
	<td><?=$r['Purse']; ?></td>
	<td><?=date("d.m.Y", $r['Date']); ?></td>
	<td><?=$r['Summa']; ?></td>
	<td><?=$st; ?></td>
</tr>
	<?
	}
	
	
}

?>


</table>