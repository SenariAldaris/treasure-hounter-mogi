<div class="clr"></div>

			<p class="bottom"></p>
	
		</div>
		
		<!-- end PAGE -->
		
		</div>
		<!-- end CONTENT -->	
		<div class="clr"></div>
	
	</div>
	<!-- end WRAP -->

</div>
<!-- end MAIN -->

<!-- start STATS -->
<div id="stats">

	<!-- start WRAP -->

	<script>
	function CalcTimePercent(nextpayment, t) {

	

	var time    = nextpayment - t;
	var days = parseInt(time / 86400);
	time = parseInt(time - days * 86400);
	
    var hour    = parseInt(time / 3600);
    if ( hour < 1 ) hour = 0;
    time = parseInt(time - hour * 3600);
    if ( hour < 10 ) hour = '0'+hour;
 
    var minutes = parseInt(time / 60);
    if ( minutes < 1 ) minutes = 0;
    time = parseInt(time - minutes * 60);
    if ( minutes < 10 ) minutes = '0'+minutes;
    var seconds = time;
    if ( seconds < 10 ) seconds = '0'+seconds;
 
	timer = days+' День '+hour+' Часа '+minutes+' Минут';
	document.getElementById('deptimer').innerHTML = timer;


	t = t + 1;
	setTimeout("CalcTimePercent("+i+", "+lastpayment+", "+nextpayment+", "+t+", "+p+")",1000);
}
	</script>
	
	
		
	<div class="wrap">Радуем вас стабильными выплатами уже: <span id="deptimer"></span></div>
	<!-- end WRAP -->
<?
	
	echo "<script language=\"JavaScript\">
		<!--
			CalcTimePercent(".time().", ".DATESTARTPROJECT.");
		//-->
		</script>";
		?>
</div>
<!-- end STATS -->
<!-- start FOOTER -->
<div id="footer">
<!--Powered By WmRush! E-Mail: Molart1@yandex.ru, ICQ: 578598778, Skype: molart111 -->
	<!-- start WRAP -->
	<div class="wrap">
	
		<!-- start LEFT -->
		<div class="left">
		
			<a href="/">Главная</a> &nbsp; &nbsp;
			<a href="/reg" class="inverted">Регистрация</a> &nbsp; &nbsp;
			<a href="/news">Новости</a> &nbsp; &nbsp;
            <a href="/rules">Правила</a> &nbsp; &nbsp;
			<a href="/project">О проекте</a> &nbsp; &nbsp;
			<a href="/faq">F.A.Q</a> &nbsp; &nbsp;
			<a href="/help">Поддержка</a> &nbsp; &nbsp;<br>
			2015 &copy;  All Rights Reserved.
		
		</div> 
<!-- /Yandex.Metrika counter --><!--LiveInternet counter--><script type="text/javascript"><!--
document.write("<a href='//www.liveinternet.ru/click' "+
"target=_blank><img src='//counter.yadro.ru/hit?t18.15;r"+
escape(document.referrer)+((typeof(screen)=="undefined")?"":
";s"+screen.width+"*"+screen.height+"*"+(screen.colorDepth?
screen.colorDepth:screen.pixelDepth))+";u"+escape(document.URL)+
";"+Math.random()+
"' alt='' title='LiveInternet: показано число просмотров за 24"+
" часа, посетителей за 24 часа и за сегодня' "+
"border='0' width='88' height='31'><\/a>")
//--></script><!--/LiveInternet-->


		<!-- end LEFT -->
	

		
		<div class="clr"></div>
		
	</div>
	<!-- end WRAP -->

</div>
<!-- end FOOTER -->
<!--Powered By WmRush! E-Mail: Molart1@yandex.ru, ICQ: 578598778, Skype: molart111 -->
</body>
</html>
<!--Powered By WmRush! E-Mail: Molart1@yandex.ru, ICQ: 578598778, Skype: molart111 -->