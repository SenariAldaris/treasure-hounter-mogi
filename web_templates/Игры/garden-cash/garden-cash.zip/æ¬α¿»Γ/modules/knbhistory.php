<?


if(!isset($_SESSION['id'])){
		Header("Location: /");
		exit;
}

?>


<div class="holder box grass">
				<!-- start LINK -->
			<table class="statsTable"><tr><th colspan="2">История игр КНБ:</th></tr></table>
			<table class="tablec">
			<tr class="tablec_trtop"><td>Номер игры</td><td>Противник</td><td>Итог</td></tr>
			<?
			$r = $mysql->query("SELECT * FROM db_knb_h WHERE UserId = '".$_SESSION['id']."' ORDER BY Id DESC LIMIT 30");
			if($r->rowCount() > 0){
				while($t = $r->fetch()){
			?>
			<tr>
			<td class="tablec_trnone"><?=$t['Uid']; ?></td>
			<td class="tablec_trnone"><?=$t['Login']; ?></td>
			<td class="tablec_trnone"><?=$t['Com']; ?></td>
			</tr>
			<?
				}
			}else echo '<tr><td class="tablec_trnone" colspan="3">Вы еще не играли в КНБ</td></tr>	';
			?>
			
					
			
			
			</table>