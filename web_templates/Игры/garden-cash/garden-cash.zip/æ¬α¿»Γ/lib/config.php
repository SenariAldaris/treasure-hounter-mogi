<?


define( 'DBHOST', 'localhost' ); //Хост
define( 'DBUSER', 'ce15632_wer' ); //Пользователь
define( 'DBPASS', '12345678' ); //Пароль
define( 'DBNAME', 'ce15632_wer' ); //Название базы
define( 'SITENAE', 'NameSite' ); //Название Сайта 
define( 'SITEEMAIL', 'zik1552@yandex.ru' ); //E-Mail Сайта 
define( 'DATESTARTPROJECT', 1435968000 ); //ата старта в UNIX формате


//Подключаемся к базе данных
$dsn = "mysql:host=" . DBHOST . ";dbname=" . DBNAME . "";
$opt = array(
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
);

try {
    $mysql = new PDO($dsn, DBUSER, DBPASS);
} catch (PDOException $e) {
    die('Подключение не удалось: ' . $e->getMessage());
}


$mysql->exec("SET NAMES utf8 COLLATE utf8_general_ci");
$mysql->exec("SET CHARACTER SET utf8");


@include("function.php");

if(isset($_SESSION['id'])){
	$q = $mysql->query("SELECT * FROM db_users WHERE Id = '".$_SESSION['id']."'");
	$UserInfo = $q->fetch();
}

###########################
#   Настройки деревьев    #
###########################

$price = array( //Цены на деревья
	"price_1" => 10, // 1 Дерево
	"price_2" => 50, // 2 Дерево
	"price_3" => 250, // 3 Дерево
	"price_4" => 1250, // 4 Дерево
	"price_5" => 2500, // 5 Дерево
	"price_6" => 5000 // 6 Дерево
);

$dohod = array( //Доход с одного дерева в День
	"full_1" => 0.10, // 1 Дерево
	"full_2" => 0.52, // 2 Дерево
	"full_3" => 2.67, // 3 Дерево
	"full_4" => 13.75, // 4 Дерево
	"full_5" => 28.33, // 5 Дерево
	"full_6" => 58.33 // 6 Дерево
);

$idShopPayeer = 1234567; //ID магазина Payeer
$passShopPayeer = 'fdgdfgdf'; //Пароль от магазина

$idAPIPayeer = '1234567'; //ID API Payeer
$PurseAPIPayeer = 'P1234567'; //Кошелек Payeer
$passAPIPayeer = 'fdgdfgdf'; //Пароль от API

$idShopFree = 1234567; //Id Магазина фрикасса
$passShopFree = 'fdgdfgdf'; //Секретное слово 1
$passShopFree2 = 'fdgdfgdf'; //Секретное слово 2

$wmr = ''; //WMR вебмани
$wmz = ''; //WMZ вебмани
$wme = ''; //WME вебмани


//Данные для админа! Ссылка на админку http://site.ru/index.php
$AdminLogin = 'admin'; // Логин админа
$PassAdmin = 'admin'; // Пароль админа


$refPerc = 0.1; //Рефпроцент! Сейчас 10%! Пример - 0.05 = 5%








?>
