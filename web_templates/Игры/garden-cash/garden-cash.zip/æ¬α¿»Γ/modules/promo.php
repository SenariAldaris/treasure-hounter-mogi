<?


if(!isset($_SESSION['id'])){
		Header("Location: /");
		exit;
}

?>
<div class="holder box grass">
				<!-- start LINK -->
				<div class="linkpp">
				
					<p class="title">Ваша реферальная ссылка:</p>
					<p class="url">http://<?=$_SERVER['HTTP_HOST']; ?>/?ref=<?=$_SESSION['login'];?></p>
				
				</div>
				<!-- end LINK --><br>
				
				<div class="clr"></div>
<table class="statsTable" style="margin-top:-10px;"><tr><th colspan="2">Размер 468x60:</th></tr></table>	
<BR><center><img src="../banners/468_60.jpg"><BR>
<p><span class="pptext">Ссылка на баннер:</span><div class="urlpp">http://<?=$_SERVER['HTTP_HOST']; ?>/banners/468_60.jpg</div></p></center>
<BR><center><img src="../banners/468_60.gif"><BR>
<p><span class="pptext">Ссылка на баннер:</span><div class="urlpp">http://<?=$_SERVER['HTTP_HOST']; ?>/banners/468_60.gif</div></p></center>


<BR><table class="statsTable" style="margin-top:-10px;"><tr><th colspan="2">Размер 728x90:</th></tr></table>	
<BR><center><img style="width:100%;" src="../banners/728_90.jpg"><BR>
<p><span class="pptext">Ссылка на баннер:</span><div class="urlpp">http://<?=$_SERVER['HTTP_HOST']; ?>/banners/728_90.jpg</div></p></center>
<BR><center><img style="width:100%;" src="../banners/728_90.gif"><BR>
<p><span class="pptext">Ссылка на баннер:</span><div class="urlpp">http://<?=$_SERVER['HTTP_HOST']; ?>/banners/728_90.gif</div></p></center>


<BR><table class="statsTable" style="margin-top:-10px;"><tr><th colspan="2">Размер 100x100:</th></tr></table>	
<BR><center><img src="../banners/100_100.jpg"><BR>
<p><span class="pptext">Ссылка на баннер:</span><div class="urlpp">http://<?=$_SERVER['HTTP_HOST']; ?>/banners/100_100.jpg</div></p></center>
<BR><center><img src="../banners/100_100.gif"><BR>
<p><span class="pptext">Ссылка на баннер:</span><div class="urlpp">http://<?=$_SERVER['HTTP_HOST']; ?>/banners/100_100.gif</div></p></center>


<BR><table class="statsTable" style="margin-top:-10px;"><tr><th colspan="2">Размер 125x125:</th></tr></table>	
<BR><center><img src="../banners/125_125.jpg"><BR>
<p><span class="pptext">Ссылка на баннер:</span><div class="urlpp">http://<?=$_SERVER['HTTP_HOST']; ?>/banners/125_125.jpg</div></p></center>
<BR><center><img src="../banners/125_125.gif"><BR>
<p><span class="pptext">Ссылка на баннер:</span><div class="urlpp">http://<?=$_SERVER['HTTP_HOST']; ?>/banners/125_125.gif</div></p></center>


<BR><table class="statsTable" style="margin-top:-10px;"><tr><th colspan="2">Размер 200x300:</th></tr></table>	
<BR><center><img src="../banners/200_300.jpg"><BR>
<p><span class="pptext">Ссылка на баннер:</span><div class="urlpp">http://<?=$_SERVER['HTTP_HOST']; ?>/banners/200_300.jpg</div></p></center>
<BR><center><img src="../banners/200_300.gif"><BR>
<p><span class="pptext">Ссылка на баннер:</span><div class="urlpp">http://<?=$_SERVER['HTTP_HOST']; ?>/banners/200_300.gif</div></p></center>


<BR><table class="statsTable" style="margin-top:-10px;"><tr><th colspan="2">Размер 240x400:</th></tr></table>	
<BR><center><img src="../banners/240_400.jpg"><BR>
<p><span class="pptext">Ссылка на баннер:</span><div class="urlpp">http://<?=$_SERVER['HTTP_HOST']; ?>/banners/240_400.jpg</div></p></center>
<BR><center><img src="../banners/240_400.gif"><BR>
<p><span class="pptext">Ссылка на баннер:</span><div class="urlpp">http://<?=$_SERVER['HTTP_HOST']; ?>/banners/240_400.gif</div></p></center>
