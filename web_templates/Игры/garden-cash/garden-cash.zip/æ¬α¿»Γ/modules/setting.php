<?

if(!isset($_SESSION['id'])){
		Header("Location: /");
		exit;
}
?>

<?
if(isset($_POST['pkey'])){
	$key = intval($_POST['pkey']);
//	echo  
	if(strlen($key) >= 6){
		$s = $mysql->prepare("UPDATE db_users SET PlatPass = ? WHERE Id = ?");
		$s->execute(array($key, $_SESSION['id']));
		echo TextOk("Платежный пароль успешно установлен");
		Header("Refresh: 2, /setting");
		return;
	}else echo TextNo("Платежный пароль должен быть минимум 6 цифр и не начинаться с цифры 0");	
}

if($UserInfo['PlatPass'] != ''){
	$dis = 'disabled="disabled"';
	$desc = '<span style="color:#c53939;">ПЛАТЕЖНЫЙ ПАРОЛЬ УЖЕ УСТАНОВЛЕН!</span>';
}else{ 
$dis = '';
$desc = '<span style="color:#c53939;">ПЛАТЕЖНЫЙ ПАРОЛЬ ЕЩЕ НЕ УСТАНОВЛЕН!</span>';
}

if(isset($_POST['purse']))
{
	$purse = clean($_POST['purse']);
	
	$a = $mysql->prepare("SELECT * FROM db_users WHERE Payeer = ?");
	$a->execute(array($purse));
	if($a->rowCount() == 0)
	{
		$s = $mysql->prepare("UPDATE db_users SET Payeer = ? WHERE Id = ?");
		$s->execute(array($purse, $_SESSION['id']));
		echo TextOk("Кошелек успешно установлен");
		Header("Refresh: 2, /setting");
		return;
		
	}
	else
	{
		echo TextNo("Данный кошелек уже используется другим пользователем!");	
	}
}


if($UserInfo['Payeer'] != ''){
	$disp = 'disabled="disabled"';
	$descp = '<span style="color:#c53939;">Кошелек уже установлен!</span>';
}else{ 
$disp = '';
$descp = '<span style="color:#c53939;">Кошелек еще не установлен!</span>';
}


if(isset($_POST['p1'])){
	$p1 = HashPass($_POST['p1']);
	$p2 = HashPass($_POST['p2']);
	$p3 = HashPass($_POST['p3']);
	
	if($p1 == $UserInfo['Password']){
		if($p2 == $p3){
			$mysql->query("UPDATE db_users SET Password = '$p3' WHERE Id = '".$_SESSION['id']."'");
			echo TextOk("Новый пароль установлен!");
			Header("Refresh: 2, /setting");
			return;
		}else echo TextNo("Новые пароли не совпадают!");
	}else echo TextNo("Старый пароль введен не верно!");
}


?>
<div class="holder box grass">
<div class="sadtext" style="font-size:20px;">Изменение пароля:</div>
<form action="/setting" method="post">
<table style="width:100%;font-family:cuprum; font-size:20px;"><tr style="padding:5px;"><td  style="width:100px;">Старый пароль: </td><td style="width:100px;"><input type="password" id="setnum" name="p1" placeholder="*****" style="font-size: 18px;width:100px;" class="insinput"></td></tr>
<table style="width:100%;font-family:cuprum; font-size:20px;"><tr style="padding:5px;"><td  style="width:100px;">Новый пароль: </td><td style="width:100px;"><input type="password" id="setnum" name="p2" placeholder="*****" style="font-size: 18px;width:100px;" class="insinput"></td></tr>
<table style="width:100%;font-family:cuprum; font-size:20px;"><tr style="padding:5px;"><td  style="width:100px;">Повтор пароля: </td><td style="width:100px;"><input type="password" id="setnum" name="p3" placeholder="*****" style="font-size: 18px;width:100px;" class="insinput"></td></tr>
</table>
<div style="margin-top:5px;"><input type="submit" class="button green small" value="Сменить пароль"/></div>
</form>

<br><br>



<div class="sadtext" style="font-size:20px;">Установка кошелька Payeer:</div>
<form action="/setting" method="post">
<table style="width:100%;font-family:cuprum; font-size:20px;"><tr style="padding:5px;"><td  style="width:100px;">Кошелек: </td><td style="width:100px;"><input <?=$disp; ?> type="text" id="setnum" name="purse" placeholder="P12345678" style="font-size: 18px;width:100px;" class="insinput"></td></tr>


</table>
<?=$descp; ?>
<div style="margin-top:5px;"><input type="submit" class="button green small" value="Сменить пароль"/></div>
</form>

<br><br>

<div class="sadtext" style="font-size:20px;">Платежный пароль</div><br>
		<div class="info">
		<div style="padding: 10px 10px 10px 50px;">
		Платежный пароль служит для безопасной сохранности ваших средств, благодаря ему злоумышленники не смогут вывести ваши деньги.
		<br>
		<font color="red">ВНИМАНИЕ!!! Платежный пароль не должен начинаться с цифры <b>0</b></font>
		</div>
		</div>
<form action="/setting" method="post" style="margin-top:10px;">
<table style="width:100%;font-family:cuprum; font-size:20px;" ><tr style="padding:5px;">
<td  style="width:100px;">Платежный пароль: </td>
<td style="width:100px;"><input <?=$dis; ?> type="text" id="setnum" name="pkey" placeholder="*******" style="font-size: 18px;width:100px;" class="insinput"></td></tr>
</table>
<?=$desc; ?>
<div style="margin-top:5px;"><input type="submit" class="button gray small" <?=$dis; ?> value="Установить платежный пароль"/></div>
</form>
<link rel="stylesheet" type="text/css" href="../buttons/buttons.css" />