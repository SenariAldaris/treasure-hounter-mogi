 
                    <h3>Список пользователей</h3> 
					
					
					<?
					
					if(isset($_POST['save'])) {
					$id = intval($_POST['id_u']);
					$name = ($_POST['p1']);
					$email = ($_POST['p2']);
					$p5 = ($_POST['p5']);
					$p6 = ($_POST['p6']);
					$p7 = ($_POST['p7']);
					$p8 = ($_POST['p8']);
					$p9 = ($_POST['p9']);
					$p10 = ($_POST['p10']);
					$p11 = ($_POST['p11']);
					$p12 = ($_POST['p12']);
					$p13 = ($_POST['p13']);
					$p14 = ($_POST['p14']);
					$p15 = ($_POST['p15']);
					$p16 = ($_POST['p16']);
					
					
					$w32 = $mysql->prepare("UPDATE `db_users` SET `Login` = ?, `Email` = ?, `MoneyIn` = ?, `MoneyOut` = ?, `RefId` = ?, `RefName` = ?, `CountRef` = ?, `InsertMoney` = ?, `Href` = ?, `RefMoney` = ?, `MoneyP` = ?, `MoneyB` = ?, `PlatPass` = ?, `Ban` = ?	WHERE `Id` = ?");
					$w32->execute(array($name, $email, $p5, $p6, $p7, $p8, $p9, $p10, $p11, $p12, $p13, $p14, $p15, $p16, $id));
					
					echo '<center><font color="green">Пользователь сохранен</font></center>';
					Header("Refresh: 1, /admin/index.php?page=users");
					}
					
					
					if(isset($_GET['dell'])) {
					$dell = intval($_GET['dell']);
					$mysql->query("DELETE FROM db_users WHERE Id = '$dell'");
					}
					
					
					if(isset($_GET['read'])) {
					$read = intval($_GET['read']);
					
					$pp = $mysql->prepare("SELECT * FROM db_users WHERE Id = ?");
					$pp->execute(array($read));
					$p = $pp->fetch();
					?>
					<table align="center">
					<form method="post" action="">
					<input type="hidden" name="id_u" value="<?=$p['Id']; ?>">
					<tr>
					<td>Логин: </td><td><input type="text" name="p1" value="<?=$p['Login'];?>"></td>
					</tr>
					
					<tr>
					<td>E-mail: </td><td><input type="text" name="p2" value="<?=$p['Email'];?>"></td>
					</tr>
					
					<tr>
					<td>Дата регистрации: </td><td><input type="text" name="p3" value="<?=date("d.m.Y в H:i", $p['DateReg']);?>" disabled /></td>
					</tr>
					
					
					<tr>
					<td>Дата логина: </td><td><input type="text" name="p4" value="<?=date("d.m.Y в H:i", $p['DateLogin']);?>" disabled /></td>
					</tr>
					
					<tr>
					<td>Баланс на покупки: </td><td><input type="text" name="p5" value="<?=$p['MoneyIn'];?>"></td>
					</tr>
					
					<tr>
					<td>Баланс на вывод: </td><td><input type="text" name="p6" value="<?=$p['MoneyOut'];?>"></td>
					</tr>
					
					<tr>
					<td>ID рефера: </td><td><input type="text" name="p7" value="<?=$p['RefId'];?>"  /></td>
					</tr>
					
					<tr>
					<td>Имя рефера: </td><td><input type="text" name="p8" value="<?=$p['RefName'];?>"  /></td>
					</tr>
					
					<tr>
					<td>Кол-во рефералов: </td><td><input type="text" name="p9" value="<?=$p['CountRef'];?>"  /></td>
					</tr>
					
					<tr>
					<td>?: </td><td><input type="text" name="p10" value="<?=$p['InsertMoney'];?>"  /></td>
					</tr>
					
					<tr>
					<td>Откуда пришел: </td><td><input type="text" name="p11" value="<?=$p['Href'];?>"  /></td>
					</tr>
					
					
					<tr>
					<td>Заработанно с рефералов: </td><td><input type="text" name="p12" value="<?=$p['RefMoney'];?>"  /></td>
					</tr>
					
					<tr>
					<td>Всего пополнено: </td><td><input type="text" name="p13" value="<?=$p['MoneyP'];?>"  /></td>
					</tr>
					
					<tr>
					<td>Всего выплачено: </td><td><input type="text" name="p14" value="<?=$p['MoneyB'];?>"  /></td>
					</tr>
					
					<tr>
					<td>Платежный пароль: </td><td><input type="text" name="p15" value="<?=$p['PlatPass'];?>"  /></td>
					</tr>
				
					
					
					
					<tr>
					<td>Забанить: </td><td><select name="p16">
					<option value="0" <? if($p['Ban'] == 0) echo 'selected'; ?> >Нет
					<option value="1" <? if($p['Ban'] == 1) echo 'selected'; ?>>Да
					
					</select></td>
					</tr>
					
				
					<tr>
					<td> </td><td><input type="submit" name="save" value="Сохранить"></td>
					</tr>
					</form>
					</table>
					<?
					return;
					}
					?>
					<form method="post" action="">
					<input type="text" name="us" value="">
					<input type="submit" value="Найти">
					
					</form>
                    <table border="0" width="100%" cellpadding="0" cellspacing="0" id="product-table">
						
							<tr>
                            	<th class="table-header-repeat line-left"><a href="">ID</a></th>
                                <th class="table-header-repeat line-left"><a href="">Логин</a></th>
                                <th class="table-header-repeat line-left"><a href="">Email</a></th>
                                <th class="table-header-repeat line-left"><a href="">Рефералов</a></th>
                                <th class="table-header-repeat line-left"><a href="">Баланс вывод/ввод</a></th>
                                <th class="table-header-repeat line-left"><a href="">Действие</a></th>
                                
                            </tr>
						
						<tbody>
						<?
						if(isset($_POST['us'])){
						$us = clean($_POST['us']);
						$w = 'WHERE Login = '.$us;
						}else $us = '';
$num = 20;  
if(isset($_GET['str'])){
$page = intval($_GET['str']); 
}else{
$page = 1;
} 
$result = $mysql->query("SELECT COUNT(*) AS `zxc` FROM db_users");  
$w1 = $result->fetch();
$posts = $w1['zxc'];  
$total = intval(($posts - 1) / $num) + 1;  
$page = intval($page);  
if(empty($page) or $page < 0) $page = 1;  
  if($page > $total) $page = $total;  
$start = $page * $num - $num;  
if($us == '') {
						$q = $mysql->query("SELECT * FROM db_users ORDER BY Id DESC LIMIT $start, $num");
}else {
$q = $mysql->query("SELECT * FROM db_users WHERE Login = '$us' ORDER BY id DESC LIMIT $start, $num");
}
						while($w = $q->fetch()) {
							$q2 = $mysql->query("SELECT `Id` FROM db_users WHERE RefId = '".$w['Id']."'");
							$ref_us = $q2->rowCount();
						
						?>
							<tr align="center">
                            	<td><?=$w['Id']; ?></td>
                                <td><?=$w['Login']; ?></td>
                                <td><?=$w['Email']; ?></td>
                                <td><?=$ref_us; ?></td>
                                <td><?=$w['MoneyOut']; ?> / <?=$w['MoneyIn']; ?></td>
                                <td>
								
								<a href="/admin/index.php?page=users&read=<?=$w['Id']; ?>" class="icon-1 info-tooltip" title="Редактировать пользователя" ></a>
								<a href="/admin/index.php?page=users&dell=<?=$w['Id']; ?>" class="icon-2 info-tooltip" title="Удалить пользователя" ></a>
								</td>
                            </tr>
						<? } ?>
						</tbody>
					</table>
					
					<?
					// Проверяем нужны ли стрелки назад 
if($page >= 1){				
$pervpage='';
$page2left='';
$page1left='';
$page1right='';
$page2right='';
$nextpage='';
}
if ($page != 1) $pervpage = '<a href= /admin/index.php?page=users&str=1><<</a>  
                               <a href= /admin/index.php?page=users&str='. ($page - 1) .'><</a> ';  
// Проверяем нужны ли стрелки вперед  
if ($page != $total) $nextpage = ' <a href= /admin/index.php?page=users&str='. ($page + 1) .'>></a>  
                                   <a href= /admin/index.php?page=users&str=' .$total. '>>></a>';  

// Находим две ближайшие станицы с обоих краев, если они есть  
if($page - 2 > 0) $page2left = ' <a href= /admin/index.php?page=users&str='. ($page - 2) .'>'. ($page - 2) .'</a> | ';  
if($page - 1 > 0) $page1left = '<a href= /admin/index.php?page=users&str='. ($page - 1) .'>'. ($page - 1) .'</a> | ';  
if($page + 2 <= $total) $page2right = ' | <a href= /admin/index.php?page=users&str='. ($page + 2) .'>'. ($page + 2) .'</a>';  
if($page + 1 <= $total) $page1right = ' | <a href= /admin/index.php?page=users&str='. ($page + 1) .'>'. ($page + 1) .'</a>'; 

// Вывод меню  
echo '<center>'.$pervpage.$page2left.$page1left.'<b>'.$page.'</b>'.$page1right.$page2right.$nextpage.'</center>';  
					?>
 