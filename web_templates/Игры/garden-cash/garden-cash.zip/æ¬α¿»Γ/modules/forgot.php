<?

if(isset($_SESSION['id'])){
		Header("Location: /user");
		exit;
}
if(isset($_POST['login'])){
	$login = clean($_POST['login']);
	$code = clean($_POST['captcha']);
	if(!empty($login)){
		if($code == $_SESSION["img_code"]){
			$q = $mysql->query("SELECT * FROM db_users WHERE Login = '$login' OR Email = '$login'");
			if($q->rowCount() == 1){
				$w = $q->fetch();
				include($_SERVER['DOCUMENT_ROOT']."/lib/libmail.php");
				$NewPass = generate_password(10);
				$text = 'Ваш новый пароль: <b>'.$NewPass.'</b>';
				$Md5Pass = HashPass($NewPass);
				$mysql->query("UPDATE db_users SET Password = '$Md5Pass' WHERE Id = '".$w['Id']."'");
				$m= new Mail; // начинаем 
				$m->From( SITEEMAIL ); // от кого отправляется почта 
				$m->To( $w['Email'] ); // кому адресованно
				$m->Subject( "Востановление пароля" );
				$m->Body( $text, 'html' );    				
				$m->Priority(3) ;    // приоритет письма
				$m->Send();    // а теперь пошла отправка
				echo TextOk("Новый пароль отправлен на Ваш почтовый ящик");
			}else echo TextNo("Данный логин или E-Mail не зарегистрированы в системе");
		}else echo TextNo("Не верный код с картинки");
	}else echo TextNo("Введите лоин или E-Mail");
}
?>
		<div class="info">
		<div style="padding: 10px 10px 10px 50px;">
        В случае если вы забыли либо утеряли пароль от своего аккаунта в проекте, его можно восстановить.
		</div>
		</div>
		
<div class="textbody" style="margin-top:20px;">
<form action="./forgot" method="post"><center><input type="text" class="btnreg" placeholder="Ваш логин либо email" name="login" style="width: 350px;font-size:18px;height:40px;border:2px solid #e1e1e1;margin-bottom:2px;font-family:roboto;"><br>

<div style="width: 350px;"><img style="float: right;" src="/capcha.php" alt="captcha"/><br/><input type="text" class="btnreg" placeholder="Код с картинки" style="width: 160px;font-size:18px;height:30px;border:2px solid #e1e1e1;margin-bottom:2px;font-family:roboto;" name="captcha"/><br/>
	
<BR><BR><input type="submit" class="button orange medium" value="ВОССТАНОВИТЬ"/></center></form><BR>
    


<link rel="stylesheet" type="text/css" href="buttons/buttons.css" />
</div>