<?

if(isset($_SESSION['id'])){
		Header("Location: /user");
		exit;
}
if(isset($_POST['username'])){
	$login = clean($_POST['username']);
	$pass = HashPass($_POST['password']);
	if(!empty($login)){
		if(!empty($pass)){
			$q = $mysql->prepare("SELECT * FROM db_users WHERE Login = ?");
			$q->execute(array($login));
			if($q->rowCount() == 1){
				$w = $q->fetch();
				if($w['Password'] == $pass){
					if($w['Ban'] == 0) {
						$l = $mysql->prepare("UPDATE db_users SET `DateLogin` = ? WHERE Id = ?");
						$l->execute(array(time(), $w['Id']));
						
						$_SESSION['id'] = $w['Id'];
						$_SESSION['login'] = $w['Login'];
						$ip = $_SERVER['REMOTE_ADDR'];
						$mysql->query("INSERT INTO db_logs SET UserId = '".$w['Id']."', Text = 'Вход в аккаунт IP: $ip', Date = '".time()."'");
						Header("Location: /user");
						exit();
					}else{
						echo TextNo('Вы забанены на проекте');
						$form = true;
					}
				}else{
					echo TextNo('Не верный Логин или пароль');
					$form = true;
				}
			}else{
				echo TextNo('Не верный логин или пароль');
				$form = true;
			}
		}else{
			echo TextNo('Введите пароль');
			$form = true;
		}
	}else{
		echo TextNo('Введите логин');
		$form = true;
	}
}


if($form == true){

?>

<form class="contact_form" action="" method="post" name="contact_form">

<input type="text" class="btnreg" placeholder="Ваш логин" name="username" style="width: 350px;font-size:18px;height:40px;border:2px solid #e1e1e1;margin-bottom:2px;font-family:roboto;"><span class="form_hint">От 3 до 10 символов, только буквы/цифры</span><br><br>



<input type="password" class="btnreg" placeholder="Ваш пароль" name="password" style="width: 350px;font-size:18px;height:40px;border:2px solid #e1e1e1;margin-bottom:2px;font-family:roboto;"><span class="form_hint">Не менее 6 символов</span><br><br>





	
<BR><BR><input type="submit" class="button orange medium" value="Войти"/></center><BR>
</form>
<link rel="stylesheet" type="text/css" href="/buttons/buttons.css" />
<?
}
?>