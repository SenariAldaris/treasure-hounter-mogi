<div class="textbody" style="margin-top:20px;">


<?

if(isset($_POST['login'])){
	$login = clean($_POST['login']);
	$pass = HashPass($_POST['password']);
	$email = clean($_POST['email']);
	$code = clean($_POST['captcha']);
	if(isset($_COOKIE['ref']) and $_COOKIE['ref'] != ''){
	$ref = $_COOKIE['ref'];
	}else $ref = 'zik1552';
	if(isset($_COOKIE['href']) and $_COOKIE['href'] != ''){
		$href = $_COOKIE['href'];
	}else $href = 'ЗАКЛАДКИ';
	$r = $mysql->query("SELECT `Id` FROM db_users WHERE `Login` = '$ref'");
	$refId = $r->fetch();
	if(!empty($login)){
		if(!empty($pass)){
			if($_POST['password'] == $_POST['password2']){
				if(!empty($email)){
					$d = $mysql->query("SELECT * FROM db_users WHERE Login = '$login' OR Email = '$email'");
					if($d->rowCount() == 0){
						if($code == $_SESSION["img_code"]){
							
							$regq = $mysql->prepare("INSERT INTO db_users SET `Login` = ?, `Password` = ?, `Email` = ?, `DateReg` = ?, `MoneyIn` = ?, `RefId` = ?");
							$regq->execute(array($login, $pass, $email, time(), 10, $refId['Id']));
							var_dump($regq);
							
							$regq = $mysql->prepare("INSERT INTO db_users (Login, Password, Email, DateReg, MoneyIn) VALUES (?, ?, ?, ?, ?)");
							$regq->execute(array($login, $pass, $email, time(), '10'));
							
							//$mysql->query("INSERT INTO db_users SET Login = '$login', Password = '$pass', Email = '$email', DateReg = '".time()."', MoneyIn = '10' RefId = '".$refId['Id']."'");
							$lid = $mysql->lastInsertId();
							$mysql->query("INSERT INTO db_farm SET UserId = '".$lid."', `Type` = '1', `LastDate` = '".time()."'");
							$mysql->query("UPDATE db_users SET CountRef = CountRef + '1' WHERE Login = '$ref'");
							//$mysql->query("INSERT INTO db_logs SET UserId = '".$refId['Id']."', Text = 'Регистрация аккаунта', Date = '".time()."'");
							$mysql->query("INSERT INTO db_logs SET UserId = '".$refId['Id']."', Text = 'Регистрация реферала $login', Date = '".time()."'");
							echo TextOk('Вы успешно зарегистрировались!');
						}else echo TextNo('Не верный код с картинки');
					}else echo TextNo('Данный логин или E-Mail уже используется');
				}else echo TextNo('Введите E-Mail');
			}else echo TextNo('Пароли не совпадают');
		}else echo TextNo('Введите пароль');		
	}else echo TextNo('Введите логин');
}

?>

<div class="info">
		<div style="padding: 10px 10px 10px 50px;">
        <?=SITENAE;?> - симулятор фруктового сада, полный приключений и захватывающей экономикой, построй свою стратегию и зарабатывай реальные деньги в лучшем проекте 2015 года!
		</div>
		</div>
<center><span style="color:#919191;font-size:20px;">Вас пригласил: <span style="color:#518815;"><?
if(isset($_COOKIE['ref'])){
	echo $_COOKIE['ref'];
}else echo 'Сам пришел...';
?></span></span><br><br>
<form class="contact_form" action="" method="post" name="contact_form">

<input type="text" class="btnreg" placeholder="Ваш логин" name="login" style="width: 350px;font-size:18px;height:40px;border:2px solid #e1e1e1;margin-bottom:2px;font-family:roboto;"><span class="form_hint">От 3 до 10 символов, только буквы/цифры</span><br><br>

<input type="email" class="btnreg" placeholder="Ваш email" name="email" style="width: 350px;font-size:18px;height:40px;border:2px solid #e1e1e1;margin-bottom:2px;font-family:roboto;"><span class="form_hint">Укажите ваш E-mail</span><br><br>

<input type="password" class="btnreg" placeholder="Ваш пароль" name="password" style="width: 350px;font-size:18px;height:40px;border:2px solid #e1e1e1;margin-bottom:2px;font-family:roboto;"><span class="form_hint">Не менее 6 символов</span><br><br>

<input type="password" class="btnreg" placeholder="Повтор пароля" name="password2" style="width: 350px;font-size:18px;height:40px;border:2px solid #e1e1e1;margin-bottom:2px;font-family:roboto;"><span class="form_hint">Повторите введенный пароль</span><br>

<div style="width: 350px;"><img style="float: right;" src="/capcha.php" alt="captcha"/><br/><input type="text" class="btnreg" placeholder="Код с картинки" style="width: 160px;font-size:18px;height:30px;border:2px solid #e1e1e1;margin-bottom:2px;font-family:roboto;" name="captcha"/><br/>

	
<BR><BR><input type="submit" class="button orange medium" value="ЗАРЕГИСТРИРОВАТЬСЯ"/></center><BR>
</form>


<link rel="stylesheet" type="text/css" href="/buttons/buttons.css" />
</div>