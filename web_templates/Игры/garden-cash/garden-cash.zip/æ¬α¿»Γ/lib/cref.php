<?PHP

class competition{

	var $mysql = NULL;
	var $compd = array();
	
	
	# Конструктор
	function __construct($mysql){
	
		$this->db = $mysql;
		$this->compd = $this->CompData();
		
	}
	
	# Данные конкурса
	function CompData(){
	
		$q = $this->db->query("SELECT * FROM db_competition WHERE status = '0' LIMIT 1");	
		if($q->rowCount() > 0){
			
			return $q->fetch();

				
		}else return false;
	}
	
	# Обновляем очки пользователя
	function UpdatePoints($user_id, $sum){
	
		$user_id = intval($user_id);
		$sum = round($sum, 2);
		
		if($this->compd["date_add"] >= 0 AND $this->compd["date_end"] > time()){
		
			$w = $this->db->query("SELECT RefName, RefId, DateReg FROM db_users WHERE Id = '{$user_id}'");
			$ret_d = $w->fetch();
			
			if($ret_d["DateReg"] >= $this->compd["date_add"]){
			
				# Проверяем есть ли пользователь в конкурсе
				$ref_id = $ret_d["RefId"];
				$ref = $ret_d["RefName"];
				$e = $this->db->query("SELECT * FROM db_competition_users WHERE user_id = '$ref_id'");
				if($e->rowCount() == 1){
				
					$this->db->query("UPDATE db_competition_users SET points = points + '$sum' WHERE user_id = '$ref_id'");
				
				}else $this->db->query("INSERT INTO db_competition_users (user, user_id, points) VALUES ('$ref','$ref_id','$sum')");
				
				return true;
				
			}else return false;
			
		}else return false;
		
	}
	
}



?>