<?PHP

class competitioninv{

	var $mysql = NULL;
	var $compd = array();
	
	
	# Конструктор
	function __construct($mysql){
	
		$this->db = $mysql;
		$this->compd = $this->CompData();
		
	}
	
	# Данные конкурса
	function CompData(){
	
		$q = $this->db->Query("SELECT * FROM db_competitioninv WHERE status = '0' LIMIT 1");	
		if($q->rowCount() > 0){
			
			return $q->fetch();

				
		}else return false;
	}
	
	# Обновляем очки пользователя
	function UpdatePoints($user_id, $sum){
	
		$user_id = intval($user_id);
		$sum = round($sum, 2);
		
		if($this->compd["date_add"] >= 0 AND $this->compd["date_end"] > time()){
		
			$w = $this->db->query("SELECT * FROM db_users WHERE Id = '$user_id'");
			$ret_d = $w->fetch();
			
			//if($ret_d["date_reg"] >= $this->compd["date_add"]){
			
				# Проверяем есть ли пользователь в конкурсе
				$login = $ret_d["Login"];
				//$ref = $ret_d["referer"];
				$e = $this->db->query("SELECT * FROM db_competition_usersinv WHERE user_id = '$user_id'");
				if($e->rowCount() == 1){
				
					$this->db->query("UPDATE db_competition_usersinv SET points = points + '$sum' WHERE user_id = '$user_id'");
				
				}else $this->db->query("INSERT INTO db_competition_usersinv (user, user_id, points) VALUES ('$login','$user_id','$sum')");
				
				return true;
				
			//}else return false;
			
		}else return false;
		
	}
	
}



?>