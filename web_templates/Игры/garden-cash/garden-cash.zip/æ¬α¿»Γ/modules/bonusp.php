<?

if(!isset($_SESSION['id'])){
		Header("Location: /");
		exit;
}

?>
<?
if(isset($_POST['purse'])){
if($UserInfo['MoneyP'] < 50){
	echo '<div class="error" style="font-size:22px;text-align:center;">Для того чтобы получать бонусы, необходимо пополнить баланс на 50 руб!</div>';
}
else
{
	$date = time() + (60*60*24);
	$q = $mysql->query("SELECT * FROM db_bonusp WHERE `UserId` = '".$_SESSION['id']."' ORDER BY `Id` DESC LIMIT 1");
	$s = $q->fetch();
	$time = date("d.m.Y", time());
	$purse = clean($_POST['purse']);
	$pin = clean($_POST['code']);
	if($pin == $UserInfo['PlatPass']) {
		if(!empty($purse)) {
	
	if($time != $s['Date']){
		include($_SERVER['DOCUMENT_ROOT']."/lib/cpayeer.php");
		
		
		if($UserInfo['InsertMoney'] <= 100) {
			$sum = rand(1, 15) / 100;
			$e = $mysql->prepare("INSERT INTO db_bonusp SET `UserId` = ?, `Login` = ?, `Date` = ?, `DateAdd` = ?, `Summa` = ?");
			$e->execute(array($_SESSION['id'], $_SESSION['login'], $time, time(), $sum));
			
							$payeer = new CPayeer($PurseAPIPayeer, $idAPIPayeer, $passAPIPayeer);
                            if ($payeer->isAuth())
                            {
                          
                                $arBalance = $payeer->getBalance();
								//var_dump($arBalance);
								$bal = $arBalance["balance"]["RUB"]["DOSTUPNO"];
								if($bal >= 0) {
								 $arTransfer = $payeer->transfer(array(
                                    'curIn' => 'RUB', // счет списани¤
                                    'sum' => $sum, // сумма получени¤
                                    'curOut' => 'RUB', // валюта получени¤
                                    'to' => $purse, // получатель (email)
                                  
                                    'comment' => 'Выплата с сайта '.SITENAE
                                   
                                    ));
									if (empty($arTransfer['errors']) && $arTransfer['historyId'] > 0)
									{
										$mysql->query("INSERT INTO db_logs SET UserId = '".$_SESSION['id']."', Text = 'Ежедневный бонус $sum руб.', Date = '".time()."'");
			echo TextOk("Вы успешно получили бонус в размере $sum руб");
										
									}
									else
									{
										echo '<pre>'.print_r($arTransfer["errors"], true).'</pre>';		
									}
									
								}
									
							}else{
									echo '<pre>'.print_r($payeer->getErrors(), true).'</pre>';
								}
			
		}
		
		if($UserInfo['InsertMoney'] >= 101 and $UserInfo['InsertMoney'] <= 500) {
			$sum = rand(1, 50) / 100;
			$e = $mysql->prepare("INSERT INTO db_bonusp SET `UserId` = ?, `Login` = ?, `Date` = ?, `DateAdd` = ?, `Summa` = ?");
			$e->execute(array($_SESSION['id'], $_SESSION['login'], $time, time(), $sum));
			$payeer = new CPayeer($PurseAPIPayeer, $idAPIPayeer, $passAPIPayeer);
                            if ($payeer->isAuth())
                            {
                          
                                $arBalance = $payeer->getBalance();
								//var_dump($arBalance);
								$bal = $arBalance["balance"]["RUB"]["DOSTUPNO"];
								if($bal >= 0) {
								 $arTransfer = $payeer->transfer(array(
                                    'curIn' => 'RUB', // счет списани¤
                                    'sum' => $sum, // сумма получени¤
                                    'curOut' => 'RUB', // валюта получени¤
                                    'to' => $purse, // получатель (email)
                                  
                                    'comment' => 'Выплата с сайта '.SITENAE
                                   
                                    ));
									if (empty($arTransfer['errors']) && $arTransfer['historyId'] > 0)
									{
										
										$mysql->query("INSERT INTO db_logs SET UserId = '".$_SESSION['id']."', Text = 'Ежедневный бонус $sum руб.', Date = '".time()."'");
			echo TextOk("Вы успешно получили бонус в размере $sum руб");
									}
									else
									{
										echo '<pre>'.print_r($arTransfer["errors"], true).'</pre>';		
									}
									
								}
									
							}else{
									echo '<pre>'.print_r($payeer->getErrors(), true).'</pre>';
								}
			
		}
		
		if($UserInfo['InsertMoney'] >= 501 and $UserInfo['InsertMoney'] <= 2500) {
			$sum = rand(1, 200) / 100;
			$e = $mysql->prepare("INSERT INTO db_bonusp SET `UserId` = ?, `Login` = ?, `Date` = ?, `DateAdd` = ?, `Summa` = ?");
			$e->execute(array($_SESSION['id'], $_SESSION['login'], $time, time(), $sum));
			$payeer = new CPayeer($PurseAPIPayeer, $idAPIPayeer, $passAPIPayeer);
                            if ($payeer->isAuth())
                            {
                          
                                $arBalance = $payeer->getBalance();
								//var_dump($arBalance);
								$bal = $arBalance["balance"]["RUB"]["DOSTUPNO"];
								if($bal >= 0) {
								 $arTransfer = $payeer->transfer(array(
                                    'curIn' => 'RUB', // счет списани¤
                                    'sum' => $sum, // сумма получени¤
                                    'curOut' => 'RUB', // валюта получени¤
                                    'to' => $purse, // получатель (email)
                                  
                                    'comment' => 'Выплата с сайта '.SITENAE
                                   
                                    ));
									if (empty($arTransfer['errors']) && $arTransfer['historyId'] > 0)
									{
										$mysql->query("INSERT INTO db_logs SET UserId = '".$_SESSION['id']."', Text = 'Ежедневный бонус $sum руб.', Date = '".time()."'");
			echo TextOk("Вы успешно получили бонус в размере $sum руб");
										
									}
									else
									{
										echo '<pre>'.print_r($arTransfer["errors"], true).'</pre>';		
									}
									
								}
									
							}else{
									echo '<pre>'.print_r($payeer->getErrors(), true).'</pre>';
								}
			
		}
		
		if($UserInfo['InsertMoney'] >= 2501 and $UserInfo['InsertMoney'] <= 5000) {
			$sum = rand(1, 500) / 100;
			$e = $mysql->prepare("INSERT INTO db_bonusp SET `UserId` = ?, `Login` = ?, `Date` = ?, `DateAdd` = ?, `Summa` = ?");
			$e->execute(array($_SESSION['id'], $_SESSION['login'], $time, time(), $sum));
			$payeer = new CPayeer($PurseAPIPayeer, $idAPIPayeer, $passAPIPayeer);
                            if ($payeer->isAuth())
                            {
                          
                                $arBalance = $payeer->getBalance();
								//var_dump($arBalance);
								$bal = $arBalance["balance"]["RUB"]["DOSTUPNO"];
								if($bal >= 0) {
								 $arTransfer = $payeer->transfer(array(
                                    'curIn' => 'RUB', // счет списани¤
                                    'sum' => $sum, // сумма получени¤
                                    'curOut' => 'RUB', // валюта получени¤
                                    'to' => $purse, // получатель (email)
                                  
                                    'comment' => 'Выплата с сайта '.SITENAE
                                   
                                    ));
									if (empty($arTransfer['errors']) && $arTransfer['historyId'] > 0)
									{
										
										$mysql->query("INSERT INTO db_logs SET UserId = '".$_SESSION['id']."', Text = 'Ежедневный бонус $sum руб.', Date = '".time()."'");
			echo TextOk("Вы успешно получили бонус в размере $sum руб");
									}
									else
									{
										echo '<pre>'.print_r($arTransfer["errors"], true).'</pre>';		
									}
									
								}
									
							}else{
									echo '<pre>'.print_r($payeer->getErrors(), true).'</pre>';
								}
			
		}
		
		if($UserInfo['InsertMoney'] >= 5001 and $UserInfo['InsertMoney'] <= 10000) {
			$sum = rand(1, 1500) / 100;
			$e = $mysql->prepare("INSERT INTO db_bonusp SET `UserId` = ?, `Login` = ?, `Date` = ?, `DateAdd` = ?, `Summa` = ?");
			$e->execute(array($_SESSION['id'], $_SESSION['login'], $time, time(), $sum));
			$payeer = new CPayeer($PurseAPIPayeer, $idAPIPayeer, $passAPIPayeer);
                            if ($payeer->isAuth())
                            {
                          
                                $arBalance = $payeer->getBalance();
								//var_dump($arBalance);
								$bal = $arBalance["balance"]["RUB"]["DOSTUPNO"];
								if($bal >= 0) {
								 $arTransfer = $payeer->transfer(array(
                                    'curIn' => 'RUB', // счет списани¤
                                    'sum' => $sum, // сумма получени¤
                                    'curOut' => 'RUB', // валюта получени¤
                                    'to' => $purse, // получатель (email)
                                  
                                    'comment' => 'Выплата с сайта '.SITENAE
                                   
                                    ));
									if (empty($arTransfer['errors']) && $arTransfer['historyId'] > 0)
									{
										$mysql->query("INSERT INTO db_logs SET UserId = '".$_SESSION['id']."', Text = 'Ежедневный бонус $sum руб.', Date = '".time()."'");
			echo TextOk("Вы успешно получили бонус в размере $sum руб");
										
									}
									else
									{
										echo '<pre>'.print_r($arTransfer["errors"], true).'</pre>';		
									}
									
								}
									
							}else{
									echo '<pre>'.print_r($payeer->getErrors(), true).'</pre>';
								}
			
		}
		
		if($UserInfo['InsertMoney'] >= 10001) {
			$sum = 15;
			$e = $mysql->prepare("INSERT INTO db_bonusp SET `UserId` = ?, `Login` = ?, `Date` = ?, `DateAdd` = ?, `Summa` = ?");
			$e->execute(array($_SESSION['id'], $_SESSION['login'], $time, time(), $sum));
			$payeer = new CPayeer($PurseAPIPayeer, $idAPIPayeer, $passAPIPayeer);
                            if ($payeer->isAuth())
                            {
                          
                                $arBalance = $payeer->getBalance();
								//var_dump($arBalance);
								$bal = $arBalance["balance"]["RUB"]["DOSTUPNO"];
								if($bal >= 0) {
								 $arTransfer = $payeer->transfer(array(
                                    'curIn' => 'RUB', // счет списани¤
                                    'sum' => $sum, // сумма получени¤
                                    'curOut' => 'RUB', // валюта получени¤
                                    'to' => $purse, // получатель (email)
                                  
                                    'comment' => 'Выплата с сайта '.SITENAE
                                   
                                    ));
									if (empty($arTransfer['errors']) && $arTransfer['historyId'] > 0)
									{
										$mysql->query("INSERT INTO db_logs SET UserId = '".$_SESSION['id']."', Text = 'Ежедневный бонус $sum руб.', Date = '".time()."'");
			echo TextOk("Вы успешно получили бонус в размере $sum руб");
										
									}
									else
									{
										echo '<pre>'.print_r($arTransfer["errors"], true).'</pre>';		
									}
									
								}
									
							}else{
									echo '<pre>'.print_r($payeer->getErrors(), true).'</pre>';
								}
			
		}
		
		
		
		
	}else echo TextNo("Вы уже получали бонус сегодня.");
	}else echo TextNo("Укажите кошелек Payeer.com");
	}else echo TextNo("Не верный платежный пароль");
}
}
if($UserInfo['MoneyP'] < 50){
	echo '<div class="error" style="font-size:22px;text-align:center;">Для того чтобы учать бонусы, необходимо пополнить баланс на 50 руб!</div>';
}
?>
	
	
	<div class="holder box grass">
		<div class="info">
		<div style="padding: 10px 10px 10px 50px;">
		Любому игроку проекта дается возможность получить ежедневный бонус в рублях на счет Payeer.com, сумма которого зависит от вклада в игре.
		</div>
		</div>
		<div class="sadtext" style="margin-top:10px;">
		Сумма ваших пополнений в проекте <a href="#">0-100</a> руб - ваш бонус <a href="#">до 0,15</a> руб.<br>
		Сумма ваших пополнений в проекте <a href="#">101-500</a> руб - ваш бонус <a href="#">до 0,50</a> руб.<br>
		Сумма ваших пополнений в проекте <a href="#">501-2500</a> руб - ваш бонус <a href="#">до 2</a> руб.<br>
		Сумма ваших пополнений в проекте <a href="#">2501-5000</a> руб - ваш бонус <a href="#">до 5</a> руб.<br>
		Сумма ваших пополнений в проекте <a href="#">5001-10000</a> руб - ваш бонус <a href="#">до 15</a> руб.<br>
		Сумма ваших пополнений в проекте <a href="#">более 10000</a> руб - ваш бонус <a href="#">15</a> руб.<br>
		</div>
					<br><center>
<form method="post" action="/bonusp?key=511356">
<center><div class="sadtext">Номер кошелька PAYEER:</div><input type="text" name="purse" placeholder="P12345678" style="font-size: 22px;height: auto;width:200px;" class="insinput"></center>
<BR>
<?
if($UserInfo['PlatPass'] != ''){
?>
<center><p><span style="font-size:18px;font-family:cuprum;"><B>ПЛАТЕЖНЫЙ ПАРОЛЬ:</B></span> 
<input type="password" name="code" placeholder="*******" style="width:70px;font-size: 18px;" class="insinput"></p></center>
					
					<input type="submit" value="ПОЛУЧИТЬ БОНУС" class="button green medium">
					<? } else echo '<font color="red">Установите платежный пароль в профиле</font>';  ?>
					</center><br>
					</form>
			<link rel="stylesheet" type="text/css" href="../buttons/buttons.css" />
			
<?
$d = time() - (60*60*24);
$q = $mysql->query("SELECT * FROM db_bonusp WHERE `DateAdd` > '$d' ");
$qq = $mysql->query("SELECT SUM(Summa) AS SumB FROM db_bonusp WHERE `DateAdd` > '$d'");
$w = $qq->fetch();
$r = $mysql->query("SELECT * FROM db_bonusp WHERE `Id` > 0  ORDER BY `Id` DESC LIMIT 1");
$rr = $r->fetch();
$t = $mysql->query("SELECT * FROM db_bonusp");
$tt = $t->fetch();
$e = $mysql->query("SELECT SUM(Summa) AS SumA FROM db_bonusp");
$ee = $e->fetch();
?>			
			
			<br><table class="statsTable" style="margin-top:-10px;"><tr><th colspan="2">Cтатистика:</th></tr></table>		
<div class="sadtext" style="margin-top:10px;">Всего выдано <a href="#"><?=$t->rowCount(); ?></a> бонусов на сумму <a href="#"><?=$ee['SumA']; ?></a> руб.<br>
Выдано бонусов сегодня: <a href="#"><?=$q->rowCount(); ?></a> шт. на сумму <a href="#"><?=$w['SumB']; ?></a> руб.<br>
Последний бонус выдан игроку <a href="#"><?=$rr['Login'];?></a> на сумму <a href="#"><?=$rr['Summa']; ?></a> руб.
</div>
