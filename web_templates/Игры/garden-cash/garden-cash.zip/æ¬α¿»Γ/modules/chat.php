<?


if(!isset($_SESSION['id'])){
		Header("Location: /");
		exit;
}

?>
Сюда вставить свой чат
<div class="holder box grass">
			<center><div id="chatovod197663"></div><p><a href="http://www.chatovod.ru/">Создать чат бесплатно!</a></p><script type="text/javascript">(function() {var po = document.createElement('script');po.type = 'text/javascript'; po.charset = "UTF-8"; po.async = true;po.src = ('https:' == document.location.protocol ? 'https:' : 'http:') + '//wmrush.chatovod.ru/widget.js?height=450&divId=chatovod197663';var s = document.getElementsByTagName('script')[0];s.parentNode.insertBefore(po, s);})();</script></center>