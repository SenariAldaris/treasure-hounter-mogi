<?

if(!isset($_SESSION['id'])){
		Header("Location: /");
		exit;
}
?>
<div class="holder box grass">
			
			<table class="statsTable" style="margin-top:-10px;"><tr><th colspan="2">Список логов:</th></tr></table>	
			<table class="tablec">
			<tr class="tablec_trtop1"><td>Дата</td><td>Описание действия</td></tr>
			
			<?
			$q = $mysql->query("SELECT * FROM db_logs WHERE UserId = '".$_SESSION['id']."' ORDER BY Id DESC LIMIT 20");
			while($w = $q->fetch()){
			?>
			<tr><td class="tablec_trnone2"><?=date("d.m.Y H:i", $w['Date']); ?></td>
			<td class="tablec_trnone1"><?=$w['Text']; ?></td>
			</tr>
			<? } ?>
						</table>