<?


?>
<div class="textbody">

<h2  style="margin-top:-10px;">Минутка истины...</h2>
<p>Мы позиционируем себя как экономическая игра высокой доходности. Многие из вас знакомы с проектами нашей тематики. На сегодня сложно найти честную и по настоящему доходную инвестиционную игру. Поэтому мы и решились на создание GardenCash. Собрав только лучшее из самых крупных и знаменитых проектов мы воплотили это у нас.</p>
<ul>
<li>Максимальная прозрачность и честность перед игроками</li>
<li>Никаких "Баллов" или других препятствий для вывода средств.</li>
<li>Гарантия выплаты до 90% резерва игрокам.</li>
<li>Уникальный скрипт и дизайн проекта.</li>
<li>Отличная техническая составляющая, выделенный сервер и SSL сертификат.</li>
</ul>
<p>Мы надеемся, что вы понимаете все риски создания и участия в подобных проектах. В свою очередь наша команда постарается сделать всё на высшем уровне и с минимальными рисками, ведь мы создали по настоящему качественный и уникальный проект, и не собираемся прекращать его работу и развитие, а наоборот, хотим дать надежный источник дохода и развлечения нашим любимым пользователям :) Всем хороших заработков дорогие друзья!</p>
<h2>Отзывы и выплаты на форумах:</h2>
<center><p>
<a href="http://www.rusmmg.ru/showthread.php?t=58962" target="_blank"><img src="/images/socbuttons/rusmmgp.png" alt="RusMMG" /></a>  
<a href="http://forum-profit.ru/showthread.php?t=37974" target="_blank"><img src="/images/socbuttons/forumprofit.png" alt="ForumProfit" /></a> 
<a href="http://investoday.ru/index.php?showtopic=124753" target="_blank"><img src="/images/socbuttons/investtoday.png" alt="InvestToday" /></a>
<a href="http://antimmgp.ru/showthread.php?p=82193" target="_blank"><img src="/images/socbuttons/antimmgp.png" alt="AntiMMGP" /></a>  
<a href="http://riaf.biz/index.php?topic=24055.0" target="_blank"><img src="/images/socbuttons/riaf.gif" alt="AntiMMGP" /></a>  
<a href="http://goldroyal.net/showthread.php?t=38458" target="_blank"><img src="/images/socbuttons/goldroyal.png" alt="GoldRoyal" /></a>  
<a href="http://profit-maker.org/showthread.php?t=39736" target="_blank"><img src="/images/socbuttons/profitmaker.png" alt="ProfitMaker" /></a>
<a href="http://buzines.net/topic96477.html" target="_blank"><img src="/images/socbuttons/buzines.png" alt="Buzines" /></a>
<a href="http://f-monitor.ru/forum/showthread.php?7586-Garden-cash-gardencash.biz&p=166287" target="_blank"><img src="/images/socbuttons/fmonitor.png" alt="FMonitor" /></a>
</p></center>

<h2>Статус проекта на мониторингах:</h2>

<center><p>
<a href="http://monitor-invest.net/ru/zakrep/1024-gardencash" target="_blank"><img src="http://monitor-invest.net/informer1/1024"></a>
<a href="http://www.sqmonitor.com/ru/?a=details&lid=3309" target="_blank"><img style="height:250px;" src="http://www.sqmonitor.com/ru/?a=image&lid=3309" /></a>
<a href="http://www.monitoringhyip.com/#!-8/c10es/ia3sshaj60" target="_blank"><img src="http://static.wixstatic.com/media/564be0_ddd3685fd704462e884ba965cfbe5883.gif"></a>
<a href="http://monhyip.net/hyip/garden-cash" target="_blank"><img src="http://monhyip.net/monitor/garden-cash"></a>
<a href="http://hyipinv.com/legend.php?id=2654" target="_blank"><img style="height:250px;" src="http://hyipinv.com/statusbanner.php?id=2654"></a>
</p></center>

</div>