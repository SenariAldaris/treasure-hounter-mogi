<?

if(!isset($_SESSION['id'])){
		Header("Location: /");
		exit;
}
?>
<div class="holder box grass">
            	<table class="statsTable" style="margin-top:-20px;">
					<tr>
						<th colspan="2">Описание конкурса:</th>
					</tr>
				</table>
			<br>
			<?
			$e = $mysql->query("SELECT * FROM db_competitioninv WHERE status = 0 LIMIT 1");
			if($e->rowCount() == 1){
			$c = $e->fetch();
			?>
		<div class="info">
		<div style="padding: 10px 10px 10px 50px;">
	    Каждому участнику проекта предоставляется возможность стать участником ежемесячного конкурса инвесторов в нашем проекте. Для этого вам необходимо пополнить свой счет на наибольшую сумму, по итогам конкурса награждаются 5 человек пополнившие баланс на максимальную сумму. Призы начисляются в процентах пополнения.
		</div>
		</div><br><br>
            	<table class="statsTable" style="margin-top:-20px;">
					<tr>
						<th colspan="2">Призы:</th>
					</tr>
				</table>
			<div style="font-family:cuprum;font-size:18px;margin-top:10px;margin-left:10px;">
						<li><b>1 место</b> - <?=$c["1m"]; ?> рублей <span style="color:#d22;"><b>сразу на вывод!</b></span></li>
			<li><b>2 место</b> - <?=$c["2m"]; ?> рублей <span style="color:#d22;"><b>сразу на вывод!</b></span></li>
			<li><b>3 место</b> - <?=$c["3m"]; ?> рублей <span style="color:#d22;"><b>сразу на вывод!</b></span></li>
			<li><b>4 место</b> - <?=$c["4m"]; ?> рублей <span style="color:#d22;"><b>сразу на вывод!</b></span></li>
			<li><b>5 место</b> - <?=$c["5m"]; ?> рублей <span style="color:#d22;"><b>сразу на вывод!</b></span></li>
			</div>
<br>
<center><div class="timetable"><span style="font-family:cuprum;font-size:28px;COLOR:#D22;font-weight:bold;">ДАТА НАЧАЛА КОНКУРСА: <?=date("d.m.Y : H:i", $c["date_add"]); ?><BR>ДАТА ОКОНЧАНИЯ КОНКУРСА: <?=date("d.m.Y : H:i", $c["date_end"]); ?></span></div></center>
			<br><br><table class="statsTable" style="margin-top:-10px;"><tr><th colspan="2">Список участников:</th></tr></table>
<?PHP
	
	# Список пользователей
	$q = $mysql->query("SELECT * FROM db_competition_usersinv ORDER BY points DESC LIMIT 100");
	if($q->rowCount() > 0){
	
	?>			
			<table class="tablec">
			<tr class="tablec_trtop"><td>Логин</td><td>Пополнено</td><td>Приз</td></tr>
			<?PHP
		$position = 1;
		while($data = $q->fetch()){
		
		?>
			<tr align="center" class="tablec_trnone">
					<td><b><?=$data["user"]; ?></b></td>
					<td><?=sprintf("%.0f",$data["points"]); ?> руб.</td>
					<td><?=(intval($c["{$position}m"]) > 0) ? $c["{$position}m"]." Руб." : "-" ?> </td>
				</tr>	
<? 
$position++;
		}
?>				
			</table>
			<?
}else echo "<center><b><font color = 'red'>Нет участников в конкурсе</font></b></center><BR />";

			}else echo "<center><b><font color = 'red'>В данный момент конкурс не проводится</font></b></center><BR />"; 
			
			?>