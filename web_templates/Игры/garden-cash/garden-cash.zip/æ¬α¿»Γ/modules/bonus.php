<?

if(!isset($_SESSION['id'])){
		Header("Location: /");
		exit;
}

?>
<?
if(isset($_GET['key'])){
	$date = time() + (60*60*24);
	$q = $mysql->query("SELECT * FROM db_bonus WHERE `UserId` = '".$_SESSION['id']."' ORDER BY `Id` DESC LIMIT 1");
	$s = $q->fetch();
	$time = date("d.m.Y", time());
	
	if($time != $s['Date']){
		if($UserInfo['InsertMoney'] <= 100) {
			$sum = rand(1, 15) / 100;
			$e = $mysql->prepare("INSERT INTO db_bonus SET `UserId` = ?, `Login` = ?, `Date` = ?, `DateAdd` = ?, `Summa` = ?");
			$e->execute(array($_SESSION['id'], $_SESSION['login'], $time, time(), $sum));
			$mysql->query("UPDATE db_users SET `MoneyIn` = `MoneyIn` + '$sum' WHERE `Id` = '".$_SESSION['id']."'");
			$mysql->query("INSERT INTO db_logs SET UserId = '".$_SESSION['id']."', Text = 'Ежедневный бонус $sum руб.', Date = '".time()."'");
			echo TextOk("Вы успешно получили бонус в размере $sum руб");
		}
		
		if($UserInfo['InsertMoney'] >= 101 and $UserInfo['InsertMoney'] <= 500) {
			$sum = rand(1, 50) / 100;
			$e = $mysql->prepare("INSERT INTO db_bonus SET `UserId` = ?, `Login` = ?, `Date` = ?, `DateAdd` = ?, `Summa` = ?");
			$e->execute(array($_SESSION['id'], $_SESSION['login'], $time, time(), $sum));
			$mysql->query("UPDATE db_users SET `MoneyIn` = `MoneyIn` + '$sum' WHERE `Id` = '".$_SESSION['id']."'");
			$mysql->query("INSERT INTO db_logs SET UserId = '".$_SESSION['id']."', Text = 'Ежедневный бонус $sum руб.', Date = '".time()."'");
			echo TextOk("Вы успешно получили бонус в размере $sum руб");
		}
		
		if($UserInfo['InsertMoney'] >= 501 and $UserInfo['InsertMoney'] <= 2500) {
			$sum = rand(1, 200) / 100;
			$e = $mysql->prepare("INSERT INTO db_bonus SET `UserId` = ?, `Login` = ?, `Date` = ?, `DateAdd` = ?, `Summa` = ?");
			$e->execute(array($_SESSION['id'], $_SESSION['login'], $time, time(), $sum));
			$mysql->query("UPDATE db_users SET `MoneyIn` = `MoneyIn` + '$sum' WHERE `Id` = '".$_SESSION['id']."'");
			$mysql->query("INSERT INTO db_logs SET UserId = '".$_SESSION['id']."', Text = 'Ежедневный бонус $sum руб.', Date = '".time()."'");
			echo TextOk("Вы успешно получили бонус в размере $sum руб");
		}
		
		if($UserInfo['InsertMoney'] >= 2501 and $UserInfo['InsertMoney'] <= 5000) {
			$sum = rand(1, 500) / 100;
			$e = $mysql->prepare("INSERT INTO db_bonus SET `UserId` = ?, `Login` = ?, `Date` = ?, `DateAdd` = ?, `Summa` = ?");
			$e->execute(array($_SESSION['id'], $_SESSION['login'], $time, time(), $sum));
			$mysql->query("UPDATE db_users SET `MoneyIn` = `MoneyIn` + '$sum' WHERE `Id` = '".$_SESSION['id']."'");
			$mysql->query("INSERT INTO db_logs SET UserId = '".$_SESSION['id']."', Text = 'Ежедневный бонус $sum руб.', Date = '".time()."'");
			echo TextOk("Вы успешно получили бонус в размере $sum руб");
		}
		
		if($UserInfo['InsertMoney'] >= 5001 and $UserInfo['InsertMoney'] <= 10000) {
			$sum = rand(1, 1500) / 100;
			$e = $mysql->prepare("INSERT INTO db_bonus SET `UserId` = ?, `Login` = ?, `Date` = ?, `DateAdd` = ?, `Summa` = ?");
			$e->execute(array($_SESSION['id'], $_SESSION['login'], $time, time(), $sum));
			$mysql->query("UPDATE db_users SET `MoneyIn` = `MoneyIn` + '$sum' WHERE `Id` = '".$_SESSION['id']."'");
			$mysql->query("INSERT INTO db_logs SET UserId = '".$_SESSION['id']."', Text = 'Ежедневный бонус $sum руб.', Date = '".time()."'");
			echo TextOk("Вы успешно получили бонус в размере $sum руб");
		}
		
		if($UserInfo['InsertMoney'] >= 10001) {
			$sum = 15;
			$e = $mysql->prepare("INSERT INTO db_bonus SET `UserId` = ?, `Login` = ?, `Date` = ?, `DateAdd` = ?, `Summa` = ?");
			$e->execute(array($_SESSION['id'], $_SESSION['login'], $time, time(), $sum));
			$mysql->query("UPDATE db_users SET `MoneyIn` = `MoneyIn` + '$sum' WHERE `Id` = '".$_SESSION['id']."'");
			$mysql->query("INSERT INTO db_logs SET UserId = '".$_SESSION['id']."', Text = 'Ежедневный бонус $sum руб.', Date = '".time()."'");
			echo TextOk("Вы успешно получили бонус в размере $sum руб");
		}
		
		
		
		
	}else echo TextNo("Вы уже получали бонус сегодня.");
}
?>
	
	
	<div class="holder box grass">
		<div class="info">
		<div style="padding: 10px 10px 10px 50px;">
		Любому игроку проекта дается возможность получить ежедневный бонус в рублях для покупок, сумма которого зависит от вклада в игре.
		</div>
		</div>
		<div class="sadtext" style="margin-top:10px;">
		Сумма ваших пополнений в проекте <a href="#">0-100</a> руб - ваш бонус <a href="#">до 0,15</a> руб.<br>
		Сумма ваших пополнений в проекте <a href="#">101-500</a> руб - ваш бонус <a href="#">до 0,50</a> руб.<br>
		Сумма ваших пополнений в проекте <a href="#">501-2500</a> руб - ваш бонус <a href="#">до 2</a> руб.<br>
		Сумма ваших пополнений в проекте <a href="#">2501-5000</a> руб - ваш бонус <a href="#">до 5</a> руб.<br>
		Сумма ваших пополнений в проекте <a href="#">5001-10000</a> руб - ваш бонус <a href="#">до 15</a> руб.<br>
		Сумма ваших пополнений в проекте <a href="#">более 10000</a> руб - ваш бонус <a href="#">15</a> руб.<br>
		</div>
					<br><center><a href="/bonus?key=511356" class="button green medium">ПОЛУЧИТЬ БОНУС</a></center><br>
			<link rel="stylesheet" type="text/css" href="../buttons/buttons.css" />
			
<?
$d = time() - (60*60*24);
$q = $mysql->query("SELECT * FROM db_bonus WHERE `DateAdd` > '$d' ");
$qq = $mysql->query("SELECT SUM(Summa) AS SumB FROM db_bonus WHERE `DateAdd` > '$d'");
$w = $qq->fetch();
$r = $mysql->query("SELECT * FROM db_bonus WHERE `Id` > 0  ORDER BY `Id` DESC LIMIT 1");
$rr = $r->fetch();
$t = $mysql->query("SELECT * FROM db_bonus");
$tt = $t->fetch();
$e = $mysql->query("SELECT SUM(Summa) AS SumA FROM db_bonus");
$ee = $e->fetch();
?>			
			
			<br><table class="statsTable" style="margin-top:-10px;"><tr><th colspan="2">Cтатистика:</th></tr></table>		
<div class="sadtext" style="margin-top:10px;">Всего выдано <a href="#"><?=$t->rowCount(); ?></a> бонусов на сумму <a href="#"><?=$ee['SumA']; ?></a> руб.<br>
Выдано бонусов сегодня: <a href="#"><?=$q->rowCount(); ?></a> шт. на сумму <a href="#"><?=$w['SumB']; ?></a> руб.<br>
Последний бонус выдан игроку <a href="#"><?=$rr['Login'];?></a> на сумму <a href="#"><?=$rr['Summa']; ?></a> руб.
</div>
