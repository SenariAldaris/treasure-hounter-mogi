<?

function cleanUrl($var){
	$replace = array(
						'http://' => '', 
						'https://' => ''
						);
        
        $var = str_replace(array_keys($replace), array_values($replace), trim($var));
		return substr($var, 0, strpos($var, "/"));
        unset($var, $replace);
	//return $var;
}

 function generate_password($number)
  {
    $arr = array('a','b','c','d','e','f',
                 'g','h','i','j','k','l',
                 'm','n','o','p','r','s',
                 't','u','v','x','y','z',
                 'A','B','C','D','E','F',
                 'G','H','I','J','K','L',
                 'M','N','O','P','R','S',
                 'T','U','V','X','Y','Z',
                 '1','2','3','4','5','6',
                 '7','8','9','0','.',',',
                 '(',')','[',']','!','?',
                 '&','^','%','@','*','$',
                 '<','>','/','|','+','-',
                 '{','}','`','~');
    // Генерируем пароль
    $pass = "";
    for($i = 0; $i < $number; $i++)
    {
      // Вычисляем случайный индекс массива
      $index = rand(0, count($arr) - 1);
      $pass .= $arr[$index];
    }
    return $pass;
  }

	function clean($var){
        $replace = array(
						'"' => '', 
						"'" => '', 
						'`' => '', 
						'{' => '', 
						'}' => '', 
						'<' => '', 
						'>' => '',
						'%' => '',
						',' => '',
						'SELECT' => '',
						'DELETE' => '',
						'select' => '',
						'Delete' => '',
						'Select' => ''
						
						);
        
        return @htmlspecialchars(str_replace(array_keys($replace), array_values($replace), trim($var)));
        unset($var, $replace);
    }
	
	function HashPass($var) {
		return md5("Powered By Skype:zik1552:".$var);
	}
	
	function TextOk($var){
		return '<div class="socusses">'.$var.'</div>';
	}
	
	function TextNo($var){
		return '<div class="error">'.$var.'</div>';
	}
?>