<!--Powered By WmRush! E-Mail: Molart1@yandex.ru, ICQ: 578598778, Skype: molart111 -->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>GardenCash - Экономическая с выводом денег</title>

<!-- start CSS -->
<link href="/css/fonts/osans/osans.css" rel="stylesheet" type="text/css" />
<link href="/css/fonts/inglobal/inglobal.css" rel="stylesheet" type="text/css" />
<link href="/css/style.css" rel="stylesheet" type="text/css" />

<meta name="viewport" content="width=1040" />

<link href="/images/favicon.ico" rel="icon" type="image/x-icon" />
</head>

<body>
<!--Powered By WmRush! E-Mail: Molart1@yandex.ru, ICQ: 578598778, Skype: molart111 -->
<!-- start HEADER -->
<div id="header">

	<!-- start WRAP -->
	<div class="wrap">
	
		<a href="/" class="logo"></a>
		
		<!-- start BUTTONS -->
		<ul class="buttons">
		
			<li><a href="https://vk.com/gardencash" class="fb op" target="_blank">Группа ВКонтакте</a></li>
			<li><a href="/trust" class="rep op">Гарантии проекта</a></li>   
		
		</ul>
		<!-- end BUTTONS -->
		<?
		if(isset($_SESSION['id'])){
		?>
				<!-- start BUTTONS -->
		<ul class="buttons right">
		
			<li><a href="/garden" class="op">МОЙ САД</a></li>
			<li><a href="/referals" class="op">МОИ РЕФЕРАЛЫ</a></li>
			<li><a href="/logout" class="op">ВЫХОД</a></li>
		
		</ul>
		<!-- end BUTTONS -->
		<? } else { ?>		
		
		<script language=javascript>
		function checklogin() {   
		  if (document.loginform.username.value=='') {
		    alert("Вы не ввели логин!");
		    document.loginform.username.focus();
		    return false;
		  }
		  if (document.loginform.password.value=='') {
		    alert("Вы не ввели пароль!");
		    document.loginform.password.focus();
		    return false;
		  }
		  return true;
		}
		</script>

		<div id="login">
		
			<form method="post" name="loginform" action="/login">

				

				<input type="text" name="username" placeholder="логин" class="username" value="" />
				<input type="password" name="password" placeholder="пароль" class="password" value=""  />
								<input class="headerinput" type="submit" value=" " />
				<a href="/forgot" class="op">?</a>
			
				<div class="clr"></div>

			</form>
		<!--Powered By WmRush! E-Mail: Molart1@yandex.ru, ICQ: 578598778, Skype: molart111 -->
		</div>
		<? } ?>
				<div class="clr"></div>
		
		<p class="devider"></p>
		
		<!-- start NAVIGATION -->
		<ul class="navigation left">
			<li><a href="/">Главная</a></li>
			<?
			if(isset($_SESSION['id'])){
			?>
						<li><a href="/user/" class="inverted">Профиль</a></li>
			<? } else { ?>
			<li><a href="/reg/" class="inverted">Регистрация</a></li>
			<? } ?>
						<li><a href="/news">Новости</a></li>
		</ul>
		<!-- end NAVIGATION -->
		
		<!-- start NAVIGATION -->
		<ul class="navigation right">
			<li><a href="/project">О проекте</a></li>
			<li><a href="/faq">F.A.Q</a></li>
			<li><a href="/help">Поддержка</a></li>
		
		</ul>
		<!-- end NAVIGATION -->
		
		<div class="clr"></div>
	
	</div>
	<!-- end WRAP -->

</div>
<!-- end HEADER -->

<?
if(!isset($_GET['page']) or $_GET['page'] == 'index'){
?>
<!-- start TOP -->
<div id="top">

		<!-- start HOME -->
	<div class="home">
	
		<!-- start WRAP -->
		<div class="wrap">
		<
		
			<p class="welcome"></p>
			<p class="name"></p>
			<p class="tag"></p>
			
			
			<!-- start PLAN -->
			<div class="plan">
			<!--Powered By WmRush! E-Mail: Molart1@yandex.ru, ICQ: 578598778, Skype: molart111 -->
				<p class="image one"></p>
				<p class="percentage">Вишня</p>
				<p class="period">Доход 30% в месяц</p>
				<p class="limit">Цена: <?=$price['price_1']; ?> руб.</p>
			
			</div>
			<!-- end PLAN -->
			
			<!-- start PLAN -->
			<div class="plan">
			
				<p class="image two"></p>
				<p class="percentage">Слива</p>
				<p class="period">Доход 31% в месяц</p>
				<p class="limit">Цена: <?=$price['price_2']; ?> руб.</p>
			
			</div>
			<!-- end PLAN -->
			
			<!-- start PLAN -->
			<div class="plan">
			
				<p class="image three"></p>
				<p class="percentage">Яблоня</p>
				<p class="period">Доход 32% в месяц</p>
				<p class="limit">Цена: <?=$price['price_3']; ?> руб.</p>
			
			</div>
			<!-- end PLAN -->
			
			<!-- start PLAN -->
			<div class="plan">
			
				<p class="image four"></p>
				<p class="percentage">Персик</p>
				<p class="period">Доход 33% в месяц</p>
				<p class="limit">Цена: <?=$price['price_4']; ?> руб.</p>
			
			</div>
			<!-- end PLAN -->
			
			<!-- start PLAN -->
			<div class="plan">
			
				<p class="image five"></p>
				<p class="percentage">Груша</p>
				<p class="period">Доход 34% в месяц</p>
				<p class="limit">Цена: <?=$price['price_5']; ?> руб.</p>
			
			</div>
			<!-- end PLAN -->
			
			<!-- start PLAN -->
			<div class="plan">
			
				<p class="image six"></p>
				<p class="percentage">Апельсин</p>
				<p class="period">Доход 35% в месяц</p>
				<p class="limit">Цена: <?=$price['price_6']; ?> руб.</p>
			
			</div>
			<!-- end PLAN -->
			
			<div class="clr"></div>
			
		
		</div>
		<!-- end WRAP -->
		
	</div>
	<!-- end HOME -->
	
</div>
<!-- end TOP -->
<? } else { ?>

<!-- start TOP -->
<div id="top" class="pageTitle">

		<!-- start WRAP -->
	<div class="wrap">
	
		<h2> > <?=$PageTitle; ?></h2>
	
	</div>
	<!-- end WRAP -->
	
</div>
<!-- end TOP -->
<? } ?>
<!--Powered By WmRush! E-Mail: Molart1@yandex.ru, ICQ: 578598778, Skype: molart111 -->

<!-- start MAIN -->
<div id="main">

	<!-- start WRAP -->
	<div class="wrap">
	

<?
if(isset($_GET['page']) and $_GET['page'] == 'project' or $_GET['page'] == 'reg' or $_GET['page'] == 'login' or $_GET['page'] == '404' or $_GET['page'] == 'news' or $_GET['page'] == 'faq' or $_GET['page'] == 'trust' or $_GET['page'] == 'rules' or $_GET['page'] == 'forgot' or $_GET['page'] == 'help'){
?>
<!-- start PAGE -->
		<div class="page box grass">
				
<div class="textbody">

<? } elseif($_GET['page'] == 'index' or !isset($_GET['page'])) { ?>
		

<? } else { ?>


<div class="leftmenu">
<?
include_once("style/menu.php");
?>

		</div>
		<!-- end MENU -->		
		<!-- start CONTENT -->
		<div id="content">
		

			<!-- start TOP -->
		
<? } ?>
					