<div class="textbody">



<span style="font-size:28px;"><center>Всем посетителям и игрокам проекта GardenCash оказывается техническая поддержка 24 часа в сутки и 7 дней в неделю в режиме <b>онлайн</b>. Вы можете задать интересующий вас вопрос касательно нашего проекта операторам.<br></span>

<br><br>
<span style="font-size:28px;"><b>Вы можете задать вопрос напрямую администратору по почте:</b><span><br>
<span style="font-size:25px;color:blue;"><b>gardencashbiz@gmail.com</b><span></center>
<br>
</div>